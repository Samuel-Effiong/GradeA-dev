"""H-165: for every mutant, and at the red commit, the tests that fail
must be the expected set and nothing else. Written on 2026-10-07 16:18 BEFORE any
test run of H-165, by reading every one of the module's 31 tests (30 at the red commit) against
every mutant and against its fixture's real values; the only code
executed was two production functions called directly on rows I built
(student_submission_to_html for the byte-for-byte checksums, and
html_to_prosemirror_text to see that the fixed line survives it). No
mutant was applied to anything. A test is named Class.method.
Usage: python expected_kills.py <battery_dir>
       python expected_kills.py --repro <log of the module at the red commit>"""
import re
import sys
from pathlib import Path

A = "AnOrdinaryDocumentIsWhatItWas"
B = "TheBuilderNeverRaisesOnTheShape"
R = "AnAffectedRowIsReadNotRefused"
G = "APaperWithNothingPrintableIsNotGraded"
W = "TheWayRoundIsReadableAnswers"
S = "APaperWithSomeLeftOutIsGradedAndFlagged"
O = "AnOrdinaryPaperIsNotFlagged"
X = "TheWritersRefuseWhatTheBuilderRefusedForThem"
A1 = (A, "test_a_list_of_objects_byte_for_byte")
A2 = (A, "test_an_empty_value_byte_for_byte")
B1 = (B, "test_nothing_printable_says_so_in_one_fixed_line")
B2 = (B, "test_some_left_out_prints_the_rest_and_says_so")
B3 = (B, "test_the_form_a_student_reads_before_release_has_the_same_line")
B4 = (B, "test_what_can_be_printed_is_decided_in_one_place")
R1 = (R, "test_the_student_reads_the_unreleased_paper")
R2 = (R, "test_the_student_reads_it_on_the_assignment")
R3 = (R, "test_a_read_that_rebuilds_an_empty_stored_document")
R4 = (R, "test_a_student_is_not_told_more_than_the_line")
G1 = (G, "test_no_paid_call_is_made")
G2 = (G, "test_the_teacher_is_told_what_to_do")
G3 = (G, "test_the_paper_is_put_in_the_review_queue")
G4 = (G, "test_nothing_of_a_grade_is_written_and_no_claim_is_left")
G5 = (G, "test_refused_twice_the_reason_stands_once")
G6 = (G, "test_every_such_shape_is_refused")
G7 = (G, "test_the_grade_route_answers_400_with_that_sentence")
G_ALL = {G1, G2, G3, G4, G5, G6, G7}
W1 = (W, "test_a_new_upload")
W2 = (W, "test_the_edit_by_text")
W3 = (W, "test_a_refusal_before_the_cure_does_not_stay_on_the_paper")
S1 = (S, "test_the_grade_is_saved_and_the_paper_flagged")
S2 = (S, "test_it_is_not_refused")
S3 = (S, "test_the_reason_stands_beside_the_others")
O1 = (O, "test_grading_leaves_no_such_reason")
X1 = (X, "test_the_upload_refuses_a_list_that_is_not_all_objects")
X2 = (X, "test_the_edit_refuses_a_list_that_is_not_all_objects")
X5 = (X, "test_the_edits_refusal_refunds_the_charge")
#: Never in a set: A.test_neither_line_is_part_of_the_other (two constants
#: of the test file), R.test_the_fixture_is_what_it_says, X's two controls
#: (what was refused is still refused; what was accepted is still
#: accepted). They are controls and are NOT evidence of this row's change.
#: W1 and W2 are controls too (both writers replaced the value before
#: this row); U5 is there to show them red.
#: The line is asserted wherever a document is read, so U2 and U3 fail
#: the same eight tests.
THE_LINE = {B1, B2, B3, R1, R2, R3, R4, S1}

EXPECTED = {
    # a value that is not a list is walked, not refused: an object or a
    # string still yields nothing printable ("all"); a number or `true`
    # cannot be walked and raises. Only the tests that try those two.
    "U1": {B1, B4, G6},
    # the fixed line is not printed.
    "U2": set(THE_LINE),
    # the two lines are swapped.
    "U3": set(THE_LINE),
    # no refusal up front: the paper is graded (the grader is replaced),
    # saved and flagged; every test that expects the refusal fails.
    "U4": G_ALL | {W3},
    # EVERY paper is refused: the cured paper and the paper with some left
    # out cannot be graded through grade_engine. Tests that save a grade
    # directly are untouched.
    "U5": {W1, W2, W3, S2},
    # the refusal does not put the paper in the queue.
    "U6": {G3, W3},
    # a second refusal adds the reason a second time.
    "U7": {G5},
    # the refusal's tier is moderate.
    "U8": {G3},
    # grading does not add the reason (and so logs nothing).
    "U9": {S1, S3},
    # grading adds the reason and does not log.
    "U10": {S1},
    # the read that stores a rebuilt document does not log.
    "U11": {R3},
    # the log line carries the value, not its kind.
    "U12": {R3, S1},
    # the upload accepts any list again.
    "U13": {X1},
    # the edit accepts any list again. X5 was added on 2026-10-07 16:34, still
    # before any run, with the test of commit 2b7e812e (the refusal
    # refunds the charge). Read against all 18: it sends a list holding a
    # string through the edit and expects the refusal and one refund, so
    # only U14, which lets that list through, fails it. It is not in the
    # red commit's set: the test does not exist at 122b28de.
    "U14": {X2, X5},
    # the refusal is not one of the errors shown to a user.
    "U15": {G2, G7},
    # grading's reason is moderate.
    "U16": {S1},
    # an empty value is treated as unreadable.
    "U17": {A2, B4},
    # the line is printed for every paper.
    "U18": {A1, A2, O1},
}
#: the red commit 122b28de (tests only). Red: everything that needs the
#: builder not to raise, the refusal, the reason or the writers' own
#: check. Green there: A's three, R's fixture control, W1 and W2 (the
#: cures work before the change), O1, X's two controls.
REPRO = {B1, B2, B3, B4, R1, R2, R3, R4, W3, S1, S2, S3, X1, X2} | G_ALL
LINE = re.compile(r"^(?:FAIL|ERROR): (test_\w+) \(([\w.]+)\)", re.M)


def failing(text):
    return {(path.split(".")[-2], name) for name, path in LINE.findall(text)}


def compare(label, got, expected):
    extra, missing = got - expected, expected - got
    print(
        f"{label}: {len(got)} failing, {'as expected' if got == expected else 'DIFFERS'}"
        + (f"; unexpected: {sorted(extra)}" if extra else "")
        + (f"; expected but passed: {sorted(missing)}" if missing else "")
    )
    return got != expected


if sys.argv[1] == "--repro":
    bad = compare("repro", failing(Path(sys.argv[2]).read_text(errors="replace")), REPRO)
    print("the red set is the expected one" if not bad else "the red set differs")
else:
    logs = Path(sys.argv[1]) / "logs"
    bad = sum(
        compare(mutant, failing((logs / f"{mutant}.log").read_text(errors="replace")), expected)
        for mutant, expected in EXPECTED.items()
    )
    print("every mutant's failing set is the expected one" if not bad else f"{bad} mutant(s) differ")
sys.exit(1 if bad else 0)
