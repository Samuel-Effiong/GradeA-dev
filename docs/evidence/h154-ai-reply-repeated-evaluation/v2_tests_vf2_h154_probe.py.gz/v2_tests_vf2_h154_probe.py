"""v2's probe for H-154 (d5). Copy to students/tests_vf2_h154_probe.py of
the scratch worktree; never committed to the branch. Written 2026-10-07
before any run, after reading a3c3a194 (code and every test line by line)
and the one commit more of ba684640 (tests and runner only).

d5's tests hold the two halves apart: the grader's result for a reply
(ai_processor), and the save of a hand-made result (students). These go
through the WHOLE pipeline, students.services.grade_engine, with only the
provider call and the two follow-up tasks replaced: the reply is turned
into a result by the real grader, saved by the real save, and the prompt
for the feedback formatter is taken as the pipeline queued it.

  E1  a short paper whose reply repeats question 2 (8, then 10). Saved:
      24 of 30, the paper in the review queue with the reason
      ai_reply_corrected naming question 2, the saved note CORRECTED. The
      formatter's prompt has the arithmetic and no word of the correction.
  E2  a reply with an evaluation for a question that does not exist (50
      points): 24 of 30, the reason counts one unmatched, no repeat.
  E3  the reply's repeat carries one of the system's two marks and the
      higher score: still 24 of 30.
  E4  E1's paper released: the student reads the score 24 and nothing of
      the correction anywhere in the answer; no review reasons.
  E5  a long paper (marked in parts) whose part repeats a question: the
      SAVED note is CORRECTED and the paper is in the review queue.

Rule 19, which mutant shows which probe red: E1 under W1 (the note keeps
PASS) and W2 (the formatter is sent the whole note); E2 under W1 and W6
(strays dropped, not counted); E3 under W3 (short path not stamped); E4
under W4 (the student reads the saved result unfiltered); E5 under W1 and
W5 (the long path's note is not carried).
"""

import json
import types
from decimal import Decimal
from unittest.mock import patch

from django.core.cache import cache
from django.test import TransactionTestCase, override_settings
from django.urls import reverse
from rest_framework.test import APIClient

import ai_processor.tests_reply_repeated_evaluation as d5t
from ai_processor import services as ai_services
from ai_processor.services import AIProcessor
from assignments.models import Assignment, AssignmentStatus
from classrooms.models import Course, EnrollmentStatusType, Session, StudentCourse
from students.models import StudentSubmission
from students.services import grade_engine
from users.models import CustomUser, UserTypes

CORRECTION_WORDS = (
    "CORRECTED",
    "left out",
    "repeated",
    "correction_note",
    "unmatched",
    "ai_reply_corrected",
)


@override_settings(
    GRADING_SECOND_OPINION_ENABLED=False,
    GRADING_EVIDENCE_ENFORCEMENT=ai_services.MODE_LOG,
)
class VF2ACorrectedReplyThroughThePipeline(TransactionTestCase):
    def setUp(self):
        cache.clear()
        self.addCleanup(cache.clear)
        self.teacher = CustomUser.objects.create_user(
            email="vf2-h154-teacher@example.com", user_type=UserTypes.TEACHER
        )
        self.student = CustomUser.objects.create_user(
            email="vf2-h154-student@example.com", user_type=UserTypes.STUDENT
        )
        session = Session.objects.create(name="S", teacher=self.teacher)
        self.course = Course.objects.create(
            name="C", teacher=self.teacher, session=session
        )
        StudentCourse.objects.create(
            student=self.student,
            course=self.course,
            enrollment_status=EnrollmentStatusType.ENROLLED,
        )
        self.prompts = []

    def paper(self, numbers):
        assignment = Assignment.objects.create(
            title="A paper",
            course=self.course,
            status=AssignmentStatus.PUBLISHED,
            total_points=10 * len(numbers),
            questions=[d5t.essay(n) for n in numbers],
        )
        return StudentSubmission.objects.create(
            assignment=assignment,
            student=self.student,
            answers=[d5t.answer(n) for n in numbers],
        )

    def grade(self, submission, provider):
        """The real pipeline; `provider` stands where the model is called."""

        def queue(*args, **kwargs):
            self.prompts.append(str(args[1]))
            return types.SimpleNamespace(id="vf2-fake-task-id")

        with (
            patch.object(AIProcessor, "execute_graded_task") as execute,
            patch("students.services._formatted_grade_task") as formatted,
            patch("students.services.student_summary_async"),
        ):
            execute.side_effect = provider
            formatted.return_value.delay.side_effect = queue
            grade_engine(self.teacher, submission)
        self.assertGreaterEqual(execute.call_count, 1)
        return StudentSubmission.objects.get(pk=submission.pk)

    def grade_short(self, evaluations):
        submission = self.paper([1, 2, 3])
        return self.grade(
            submission,
            lambda **kwargs: d5t.reply({"question_evaluations": evaluations}),
        )

    def corrected_reasons(self, saved):
        return [
            reason
            for reason in saved.review_reasons or []
            if reason.get("type") == "ai_reply_corrected"
        ]

    def assert_24_of_30(self, saved):
        self.assertIsNotNone(saved.graded_at)
        self.assertEqual(saved.score, Decimal("24"))
        self.assertEqual(saved.max_points, 30)
        self.assertLessEqual(saved.score_percentage, 100)

    def test_e1_a_repeat_through_the_pipeline(self):
        saved = self.grade_short(
            [
                d5t.evaluation(1),
                d5t.evaluation(2, 8),
                d5t.evaluation(2, 10),
                d5t.evaluation(3),
            ]
        )

        self.assert_24_of_30(saved)
        self.assertTrue(saved.needs_review)
        self.assertEqual(
            self.corrected_reasons(saved),
            [
                {
                    "type": "ai_reply_corrected",
                    "repeated_questions": [2],
                    "repeated_dropped": 1,
                    "unmatched_dropped": 0,
                }
            ],
        )
        note = saved.feedback["score_calculation_verification"]
        self.assertEqual(note["verification_status"], "CORRECTED")
        self.assertEqual(note["manual_sum"], 24)
        # what the feedback formatter was queued with
        self.assertEqual(len(self.prompts), 1)
        prompt = self.prompts[0]
        self.assertIn("8 + 8 + 8 = 24", prompt)
        for word in CORRECTION_WORDS:
            self.assertNotIn(word, prompt)

    def test_e2_a_stray_through_the_pipeline(self):
        saved = self.grade_short(
            [
                d5t.evaluation(1),
                d5t.evaluation(2),
                d5t.evaluation(3),
                d5t.evaluation(d5t.STRAY, 50),
            ]
        )

        self.assert_24_of_30(saved)
        self.assertTrue(saved.needs_review)
        self.assertEqual(
            self.corrected_reasons(saved),
            [
                {
                    "type": "ai_reply_corrected",
                    "repeated_questions": [],
                    "repeated_dropped": 0,
                    "unmatched_dropped": 1,
                }
            ],
        )

    def test_e3_a_repeat_carrying_the_systems_mark_through_the_pipeline(self):
        for name, mark in d5t.SYSTEM_MARKS.items():
            with self.subTest(mark=name):
                cache.clear()
                saved = self.grade_short(
                    [
                        d5t.evaluation(1),
                        d5t.evaluation(2, 8),
                        dict(d5t.evaluation(2, 10), **mark),
                        d5t.evaluation(3),
                    ]
                )

                self.assert_24_of_30(saved)

    def test_e4_the_student_reads_nothing_of_the_correction(self):
        saved = self.grade_short(
            [
                d5t.evaluation(1),
                d5t.evaluation(2, 8),
                d5t.evaluation(2, 10),
                d5t.evaluation(3),
            ]
        )
        self.assertEqual(
            saved.feedback["score_calculation_verification"]["verification_status"],
            "CORRECTED",
        )
        teacher = APIClient()
        teacher.force_authenticate(self.teacher)
        with patch("students.views.notify_student_of_graded_submission"):
            released = teacher.post(
                reverse("student-submission-publish-grade", kwargs={"pk": saved.pk})
            )
        self.assertEqual(released.status_code, 200, getattr(released, "data", None))
        cache.clear()

        student = APIClient()
        student.force_authenticate(self.student)
        response = student.get(
            reverse("student-submission-detail", kwargs={"pk": saved.pk})
        )
        self.assertEqual(response.status_code, 200, getattr(response, "data", None))
        for key in ("score", "feedback", "is_published"):
            self.assertIn(key, response.data)
        self.assertTrue(response.data["is_published"])
        self.assertEqual(Decimal(str(response.data["score"])), Decimal("24"))
        self.assertTrue(response.data["feedback"])
        text = json.dumps(response.data, default=str)
        for word in CORRECTION_WORDS:
            self.assertNotIn(word, text)
        self.assertFalse(response.data.get("review_reasons"))

    def test_e5_a_long_papers_part_repeats_a_question(self):
        numbers = list(range(1, d5t.LONG_PAPER + 1))
        submission = self.paper(numbers)

        def provider(**kwargs):
            if not d5t.is_a_batch_call(kwargs):
                return d5t.reply(d5t.SUMMARY_REPLY)
            asked = d5t.numbers_asked(kwargs)
            evaluations = [d5t.evaluation(n) for n in asked]
            if 2 in asked:
                evaluations.append(d5t.evaluation(2, 10))
            return d5t.reply({"question_evaluations": evaluations})

        saved = self.grade(submission, provider)

        self.assertEqual(saved.score, Decimal(8 * d5t.LONG_PAPER))
        self.assertEqual(saved.max_points, 10 * d5t.LONG_PAPER)
        note = saved.feedback["score_calculation_verification"]
        self.assertEqual(note["verification_status"], "CORRECTED")
        self.assertTrue(saved.needs_review)
        self.assertEqual(
            self.corrected_reasons(saved),
            [
                {
                    "type": "ai_reply_corrected",
                    "repeated_questions": [2],
                    "repeated_dropped": 1,
                    "unmatched_dropped": 0,
                }
            ],
        )
        self.assertEqual(len(self.prompts), 1)
        for word in CORRECTION_WORDS:
            self.assertNotIn(word, self.prompts[0])
