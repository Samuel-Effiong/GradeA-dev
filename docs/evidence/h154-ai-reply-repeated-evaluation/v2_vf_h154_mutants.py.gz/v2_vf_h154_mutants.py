"""v2 mutants for H-154 (d5), beside d5's R1-R17.

Run from the vf2-s1 scratch worktree (detached at COMMIT, with v2's probe
copied to students/tests_vf2_h154_probe.py), inside the rule 16/13/12
wrappers, output to a file, stdin from /dev/null (rule 18).
Usage: COMMIT=<sha> MUTANT_LOGS=<dir> python vf_h154_mutants.py check |
baseline | (no args: every mutant).

Every inner run writes its OWN file: "baseline.txt", and for a mutant
"<mutant>_<who judged it>.txt".
Rule 17: every test subprocess runs with PYTHONDONTWRITEBYTECODE=1, and the
__pycache__ of the mutated module's directory is deleted before each mutant
and after each restore; `baseline` deletes it first. Database tests:
--keepdb (database test_vf2_s1, left for 0b to drop).
"""

import ast
import hashlib
import os
import pathlib
import re
import shutil
import subprocess
import sys

COMMIT = os.environ["COMMIT"]
AI = "ai_processor/services.py"
FP = "students/feedback_projection.py"
SR = "students/serializers.py"
REPLY = "ai_processor.tests_reply_repeated_evaluation"
D5 = [REPLY, "ai_processor.tests_grading_arithmetic", "students.tests_ai_reply_corrected_review"]
PROBE = ["students.tests_vf2_h154_probe"]
BASELINE = D5 + PROBE
LOGS = pathlib.Path(os.environ["MUTANT_LOGS"])  # one file per inner run

# Written 2026-10-07 before any run of this row by v2 (rules 18 and 19):
# for each mutant and each judge, the tests that must ALL be among the
# failing ones. KILLED only with the run's own "Ran" line and every named
# test failing; anything else is SURVIVED, BROKEN or KILLED_OTHER.
E1 = "test_e1_a_repeat_through_the_pipeline"
E2 = "test_e2_a_stray_through_the_pipeline"
E3 = "test_e3_a_repeat_carrying_the_systems_mark_through_the_pipeline"
E4 = "test_e4_the_student_reads_nothing_of_the_correction"
E5 = "test_e5_a_long_papers_part_repeats_a_question"
EXPECTED = {
    # Rule 19 mutants, judged by v2's probe only (their shapes are among
    # d5's R6, R11, R16, R7; d5's own tests judge those in d5's gate).
    # The saved note keeps PASS: no review reason, on either path.
    "W1_the_note_keeps_pass": {
        "v2's probe": (PROBE, (E1, E2, E5)),
    },
    # The formatter is sent the whole note.
    "W2_the_formatter_is_sent_the_whole_note": {
        "v2's probe": (PROBE, (E1, E5)),
    },
    # The short path does not stamp a reply's evaluations.
    "W3_the_short_path_does_not_stamp": {
        "v2's probe": (PROBE, (E3,)),
    },
    # Not part of H-154's change: the student's serializer returns the
    # saved result unfiltered, to show E4 can fail.
    "W4_the_student_reads_the_saved_result_whole": {
        "v2's probe": (PROBE, (E4,)),
    },
    # The long path's saved note is not carried past the second sum.
    "W5_the_long_paths_note_is_not_carried": {
        "v2's probe": (PROBE, (E5,)),
    },
    # Independent of d5's seventeen: a stray is dropped from the sum but
    # the note is only written for repeats, so a reply with strays alone
    # is saved as PASS and the paper is not flagged.
    "W6_strays_are_dropped_but_not_counted": {
        "d5's tests": ([REPLY, "ai_processor.tests_grading_arithmetic"],
                       ("test_the_note_counts_it",
                        "test_evaluation_with_no_matching_question_is_left_out_of_the_sum")),
        "v2's probe": (PROBE, (E2,)),
    },
    # Independent of d5's seventeen: only the answer-key mark counts as the
    # system's; an evaluation reused from the saved-answer store is treated
    # as a model's, so a lower returned one replaces it.
    "W7_a_stored_answer_is_not_the_systems": {
        "d5's tests": ([REPLY],
                       ("test_the_stored_one_stands_whichever_is_lower",
                        "test_a_returned_one_that_calls_itself_the_systems_does_not_lower_it")),
    },
}
PREDICTED_TO_SURVIVE = set()
# Which mutant shows which probe red (rule 19):
# E1: W1, W2. E2: W1, W6. E3: W3. E4: W4. E5: W1, W2, W5.

MUTANTS = {
    "W1_the_note_keeps_pass": (AI, [
        ("            verification[\"verification_status\"] = REPLY_CORRECTED\n",
         "            pass\n"),
    ]),
    "W2_the_formatter_is_sent_the_whole_note": (FP, [
        ("    if isinstance(note, dict) and note.get(\"verification_status\") not in (\n",
         "    if False and isinstance(note, dict) and note.get(\"verification_status\") not in (\n"),
    ]),
    "W3_the_short_path_does_not_stamp": (AI, [
        ("            self._stamp_as_a_models(evaluations, model_name)\n",
         "            pass\n"),
    ]),
    "W4_the_student_reads_the_saved_result_whole": (SR, [
        ("            return student_safe_feedback(obj.feedback)\n",
         "            return obj.feedback\n"),
    ]),
    "W5_the_long_paths_note_is_not_carried": (AI, [
        ("        if earlier.get(\"verification_status\") != REPLY_CORRECTED:\n            return\n",
         "        if True:\n            return\n"),
    ]),
    "W6_strays_are_dropped_but_not_counted": (AI, [
        ("        if repeated_dropped or unmatched_dropped:\n            repeated = [\n",
         "        if repeated_dropped:\n            repeated = [\n"),
    ]),
    "W7_a_stored_answer_is_not_the_systems": (AI, [
        ("            evaluation.get(\"graded_by\") == \"deterministic\"\n            or evaluation.get(\"from_cache\")\n        )\n\n    @staticmethod\n    def _stamp_as_a_models",
         "            evaluation.get(\"graded_by\") == \"deterministic\"\n        )\n\n    @staticmethod\n    def _stamp_as_a_models"),
    ]),
}


def parts(name):
    """A mutant as a list of (path, edits)."""
    m = MUTANTS[name]
    return m if isinstance(m, list) else [m]


ENV = {**os.environ, "EXEMPT_EMAIL_DOMAINS": "", "PYTHONDONTWRITEBYTECODE": "1"}


def sha(b):
    return hashlib.sha256(b).hexdigest()


def clear_pycache(path):
    shutil.rmtree(pathlib.Path(path).parent / "__pycache__", ignore_errors=True)


def run(labels, log_name):
    """One inner run: output straight to its own file, stdin from the null
    device, no pipe (rule 18). The file is read only after the run ends."""
    LOGS.mkdir(parents=True, exist_ok=True)
    log = LOGS / log_name
    with open(log, "wb") as fh:
        out = subprocess.run(
            [sys.executable, "manage.py", "test", *labels,
             "--settings=settings_worktree", "--noinput", "--keepdb", "-v1"],
            stdout=fh, stderr=subprocess.STDOUT, env=ENV, stdin=subprocess.DEVNULL,
        )
    o = log.read_text(errors="replace")
    failing = sorted(set(re.findall(r"^(?:FAIL|ERROR): (\w+)", o, re.M)))
    ran = next((l for l in o.splitlines() if l.startswith("Ran ")), "Ran ?")
    summary = next((l for l in o.splitlines() if l.startswith(("OK", "FAILED"))), f"? rc={out.returncode}")
    return out.returncode, ran, summary, failing, o


if sys.argv[1:] == ["check"]:
    for name in MUTANTS:
        for path, edits in parts(name):
            src = open(path).read()
            counts = [src.count(old) for old, _ in edits]
            for old, new in edits:
                src = src.replace(old, new, 1)
            ast.parse(src)
            print(name, path, counts, "parses")
    sys.exit()

if sys.argv[1:] == ["baseline"]:
    clear_pycache(AI)
    clear_pycache(FP)
    rc, ran, summary, failing, o = run(BASELINE, "baseline.txt")
    print("baseline |", ran, "|", summary, "|", failing, flush=True)
    if rc != 0:
        print(o[-8000:])
    sys.exit(rc)

for name in sys.argv[1:] or MUTANTS:
    mutated = {}
    bad = False
    for path, edits in parts(name):
        src = open(path).read()
        counts = [src.count(old) for old, _ in edits]
        if counts != [1] * len(edits):
            print(name, "APPLY_FAILED", path, counts, flush=True)
            bad = True
            break
        for old, new in edits:
            src = src.replace(old, new, 1)
        ast.parse(src)
        mutated[path] = src
    if bad:
        continue
    for who, (label_set, expected) in EXPECTED[name].items():
        try:
            for path, text in mutated.items():
                clear_pycache(path)
                open(path, "w").write(text)
            # r2: one file per judgement. The first form wrote both judgements
            # of a mutant to the same file, so the second overwrote the first.
            slug = re.sub(r"[^a-z0-9]+", "_", who.lower()).strip("_")
            rc, ran, summary, failing, _ = run(label_set, f"{name}_{slug}.txt")
            if rc == 0:
                status = "SURVIVED"
            elif ran == "Ran ?" or not failing:
                status = "BROKEN"
            elif all(name in failing for name in expected):
                status = "KILLED"
            else:
                status = "KILLED_OTHER"
            note = " (predicted to survive)" if name in PREDICTED_TO_SURVIVE else ""
            print(name, "|", who, "|", status + note, "|", ran, "|", summary,
                  "| expected", expected, "| failing", failing, flush=True)
        finally:
            for path in mutated:
                subprocess.run(["git", "checkout", "--", path], check=True)
                clear_pycache(path)
                ok = sha(open(path, "rb").read()) == sha(
                    subprocess.run(["git", "show", f"{COMMIT}:{path}"], capture_output=True).stdout
                )
                print("  restore", path, "ok" if ok else "MISMATCH", "| __pycache__ cleared", flush=True)
