"""Settings shim for the H-1 post-H-10 stampede measurement (NOT for commit).

Pins everything local and makes the server behave like production where it
matters for timing:
* DEBUG off - DEBUG=True appends every SQL statement to an in-memory log per
  request, which inflates rebuild cost and grows memory under load;
* the database and Redis are forced to dedicated local instances, never the
  production URLs that also live in .env;
* DRF throttling is disabled - a 50-request burst from one account would
  otherwise measure the throttle, not the cache.
"""
import os

os.environ["ENVIRONMENT"] = "local"
if "STAMPEDE_DB" not in os.environ or "STAMPEDE_REDIS" not in os.environ:
    raise RuntimeError("STAMPEDE_DB and STAMPEDE_REDIS must be set explicitly")
os.environ["DATABASE_URI_LOCAL"] = os.environ["STAMPEDE_DB"]
os.environ["REDIS_LOCAL_URL"] = os.environ["STAMPEDE_REDIS"]

from AutoGrader.settings import *  # noqa: E402,F401,F403
from AutoGrader.settings import DATABASES, REST_FRAMEWORK  # noqa: E402

DEBUG = False
# "testserver" is the Django test Client's host (in-process cost harness).
ALLOWED_HOSTS = ["127.0.0.1", "localhost", "testserver"]
assert DATABASES["default"]["HOST"] in ("127.0.0.1", "localhost"), DATABASES["default"]["HOST"]
assert DATABASES["default"]["NAME"].startswith("ag_h1_stampede_"), DATABASES["default"]["NAME"]
CACHES["default"]["LOCATION"] = os.environ["STAMPEDE_REDIS"]  # noqa: F405
assert "127.0.0.1" in CACHES["default"]["LOCATION"]  # noqa: F405

REST_FRAMEWORK = {
    **REST_FRAMEWORK,
    "DEFAULT_THROTTLE_CLASSES": [],
    "DEFAULT_THROTTLE_RATES": {},
}
