"""Harness C (NOT for commit): separate stampede cost from plain queueing.

At high concurrency, latency rises even when every request is a cache HIT,
because 50 concurrent requests queue on 9 workers x 4 threads. The stampede
harness recorded only COLD bursts, so its latency mixes both effects.

For each selected family, alternating ROUNDS times:
  warm burst : N concurrent requests at a warm key (all hits)
  cold burst : bump the family's scope, then N concurrent requests
Reports per family: warm vs cold p50/p95/max, and extra latency = cold - warm.
Rebuilds are counted exactly as in harness B (dedicated Redis SET delta minus
a warm-burst baseline).
"""
import json
import os
import statistics
import sys
import threading
import time

import django

django.setup()

import requests  # noqa: E402
from django.core.cache import cache  # noqa: E402
from rest_framework_simplejwt.tokens import AccessToken  # noqa: E402

sys.path.insert(0, os.path.dirname(__file__))
from targets import fixtures, targets  # noqa: E402

from AutoGrader.cache_generation import bump_many  # noqa: E402

BASE = os.environ["STAMPEDE_URL"]
LABEL = os.environ["STAMPEDE_LABEL"]
OUT = os.environ["STAMPEDE_OUT"]
N = int(os.environ.get("STAMPEDE_N", "50"))
ROUNDS = int(os.environ.get("STAMPEDE_ROUNDS", "5"))
FAMILIES = [s for s in os.environ["STAMPEDE_FAMILIES"].split(",") if s]
redis = cache.client.get_client(write=True)


def sets():
    return int(redis.info("commandstats").get("cmdstat_set", {}).get("calls", 0))


def burst(token, path, n):
    barrier = threading.Barrier(n)
    lat, codes = [None] * n, [None] * n

    def go(i):
        session = requests.Session()
        barrier.wait(timeout=60)
        t0 = time.perf_counter()
        try:
            codes[i] = session.get(BASE + path, headers={"Authorization": f"Bearer {token}"}, timeout=120).status_code
        except Exception as exc:  # recorded, not raised
            codes[i] = type(exc).__name__
        lat[i] = (time.perf_counter() - t0) * 1000

    threads = [threading.Thread(target=go, args=(i,)) for i in range(n)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    return sorted(lat), codes


def pct(sorted_lat, q):
    return sorted_lat[max(0, int(len(sorted_lat) * q) - 1)]


f = fixtures()
all_targets = {t[0]: t for t in targets(f)}
for name in FAMILIES:
    _, user, path, scopes = all_targets[name]
    token = str(AccessToken.for_user(user))
    burst(token, path, 1)  # warm the key
    warm_p50, warm_p95, cold_p50, cold_p95, warm_max, cold_max, rebuilds, non200 = [], [], [], [], [], [], [], 0
    for _ in range(ROUNDS):
        s0 = sets()
        lat, codes = burst(token, path, N)
        warm_sets = sets() - s0
        warm_p50.append(statistics.median(lat)); warm_p95.append(pct(lat, 0.95)); warm_max.append(lat[-1])
        non200 += sum(1 for c in codes if c != 200)
        bump_many(scopes)
        s1 = sets()
        lat, codes = burst(token, path, N)
        rebuilds.append((sets() - s1) - warm_sets)
        cold_p50.append(statistics.median(lat)); cold_p95.append(pct(lat, 0.95)); cold_max.append(lat[-1])
        non200 += sum(1 for c in codes if c != 200)
    med = lambda xs: round(statistics.median(xs), 1)  # noqa: E731
    row = {
        "label": LABEL, "family": name, "n": N, "rounds": ROUNDS, "non_200": non200,
        "warm_p50_ms": med(warm_p50), "warm_p95_ms": med(warm_p95), "warm_max_ms": med(warm_max),
        "cold_p50_ms": med(cold_p50), "cold_p95_ms": med(cold_p95), "cold_max_ms": med(cold_max),
        "extra_p50_ms": round(med(cold_p50) - med(warm_p50), 1),
        "extra_p95_ms": round(med(cold_p95) - med(warm_p95), 1),
        "rebuilds_median": statistics.median(rebuilds), "rebuilds_all": rebuilds,
    }
    print(json.dumps(row), flush=True)
    with open(OUT, "a") as fh:
        fh.write(json.dumps(row) + "\n")
