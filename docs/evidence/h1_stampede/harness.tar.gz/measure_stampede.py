"""Harness B: stampede and herd behaviour against a live production-shaped
gunicorn (9 workers x 4 gthreads) on a DEDICATED redis-server (NOT for commit).

Rebuild counting: the dedicated Redis instance is used by nothing else, so the
delta of `cmdstat_set` calls across a burst counts cache writes. A warm burst
of the same size runs first to measure SETs that are not cache rebuilds
(e.g. presence/activity keys), which is subtracted.

Experiments
  same-key stampede : bump the family's scope, fire N simultaneous requests at
                      that ONE key (N in 1,5,10,25,50)
  student herd      : bump `global`, K distinct students load my_courses at once
  dashboard burst   : bump the school, its admin loads every school panel at once
"""
import json
import os
import statistics
import sys
import threading
import time

import django

django.setup()

import requests  # noqa: E402
from django.core.cache import cache  # noqa: E402
from rest_framework_simplejwt.tokens import AccessToken  # noqa: E402

sys.path.insert(0, os.path.dirname(__file__))
from targets import fixtures, targets  # noqa: E402

from AutoGrader.cache_generation import SCOPE_GLOBAL, SCOPE_SCHOOL, bump_many  # noqa: E402
from classrooms.models import StudentCourse  # noqa: E402

BASE = os.environ["STAMPEDE_URL"]
LABEL = os.environ["STAMPEDE_LABEL"]
OUT = os.environ["STAMPEDE_OUT"]
FAMILIES = [s for s in os.environ.get("STAMPEDE_FAMILIES", "").split(",") if s]
redis = cache.client.get_client(write=True)


def sets():
    return int(redis.info("commandstats").get("cmdstat_set", {}).get("calls", 0))


def burst(spec):
    """spec: list of (token, path). Fire all at once; return latencies (ms),
    status codes, wall ms."""
    barrier = threading.Barrier(len(spec))
    lat, codes = [None] * len(spec), [None] * len(spec)

    def go(i, token, path):
        session = requests.Session()
        barrier.wait(timeout=60)
        t0 = time.perf_counter()
        try:
            r = session.get(BASE + path, headers={"Authorization": f"Bearer {token}"}, timeout=120)
            codes[i] = r.status_code
        except Exception as exc:  # pragma: no cover - recorded, not raised
            codes[i] = type(exc).__name__
        lat[i] = (time.perf_counter() - t0) * 1000

    threads = [threading.Thread(target=go, args=(i, t, p)) for i, (t, p) in enumerate(spec)]
    w0 = time.perf_counter()
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    return lat, codes, (time.perf_counter() - w0) * 1000


def summarise(lat):
    lat = sorted(lat)
    return {
        "p50_ms": round(statistics.median(lat), 1),
        "p95_ms": round(lat[max(0, int(len(lat) * 0.95) - 1)], 1),
        "max_ms": round(lat[-1], 1),
    }


def emit(row):
    row = {"label": LABEL, **row}
    print(json.dumps(row), flush=True)
    with open(OUT, "a") as fh:
        fh.write(json.dumps(row) + "\n")


f = fixtures()
all_targets = {t[0]: t for t in targets(f)}
chosen = [all_targets[name] for name in FAMILIES] if FAMILIES else list(all_targets.values())

for name, user, path, scopes in chosen:
    token = str(AccessToken.for_user(user))
    burst([(token, path)])  # warm the key
    for n in (1, 5, 10, 25, 50):
        s0 = sets()
        burst([(token, path)] * n)
        warm_sets = sets() - s0
        bump_many(scopes)
        s1 = sets()
        lat, codes, wall = burst([(token, path)] * n)
        cold_sets = sets() - s1
        emit({
            "experiment": "same-key stampede", "family": name, "concurrency": n,
            "rebuilds": cold_sets - warm_sets, "cold_sets": cold_sets, "warm_sets": warm_sets,
            "non_200": sum(1 for c in codes if c != 200), "wall_ms": round(wall, 1), **summarise(lat),
        })

# Student herd: global bump, K distinct students' my_courses at once.
student_ids = list(
    StudentCourse.objects.order_by("student_id").values_list("student_id", flat=True).distinct()[:50]
)
from users.models import CustomUser  # noqa: E402

students = list(CustomUser.objects.filter(id__in=student_ids))
my_courses = all_targets["11 my_courses (student)"][2]
for k in (10, 50):
    spec = [(str(AccessToken.for_user(s)), my_courses) for s in students[:k]]
    burst(spec)  # warm all K keys
    s0 = sets()
    burst(spec)
    warm_sets = sets() - s0
    bump_many([(SCOPE_GLOBAL, None)])
    s1 = sets()
    lat, codes, wall = burst(spec)
    cold_sets = sets() - s1
    emit({"experiment": "student herd after global bump", "family": "11 my_courses", "concurrency": k,
          "rebuilds": cold_sets - warm_sets, "cold_sets": cold_sets, "warm_sets": warm_sets,
          "non_200": sum(1 for c in codes if c != 200), "wall_ms": round(wall, 1), **summarise(lat)})

# Dashboard burst: school bump, its admin opens every school panel at once.
panels = [t for t in all_targets.values() if t[0].split()[0] in {"23", "24", "25", "30", "31", "32", "33"}]
token = str(AccessToken.for_user(f["admin"]))
spec = [(token, p[2]) for p in panels]
burst(spec)
s0 = sets()
burst(spec)
warm_sets = sets() - s0
bump_many([(SCOPE_SCHOOL, f["school"].id)])
s1 = sets()
lat, codes, wall = burst(spec)
cold_sets = sets() - s1
emit({"experiment": "school dashboard burst after school bump", "family": "23-25,30-33", "concurrency": len(spec),
      "rebuilds": cold_sets - warm_sets, "cold_sets": cold_sets, "warm_sets": warm_sets,
      "non_200": sum(1 for c in codes if c != 200), "wall_ms": round(wall, 1), **summarise(lat)})
