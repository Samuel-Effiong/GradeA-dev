"""Seed a stampede-measurement DB. Usage (from the stampede worktree):

    STAMPEDE_DB=... STAMPEDE_REDIS=... PYTHONPATH=<scratchpad>/stampede \
      DJANGO_SETTINGS_MODULE=stampede_settings python seed.py <teachers_per_school> [student_pool]

10 schools x T teachers x 4 courses; 30 students per course from a pool of
student_pool (default 600, the value the s1/s2 runs used); 8 published assignments per course; ~30% graded submissions. bulk_create
bypasses signals (seeding must not depend on cache wiring) and model save()
overrides.
"""
import random
import sys
import time
from datetime import timedelta

import django

django.setup()

from django.contrib.auth.hashers import make_password  # noqa: E402
from django.db import connection  # noqa: E402
from django.utils import timezone  # noqa: E402

from assignments.models import Assignment, AssignmentStatus  # noqa: E402
from classrooms.models import (  # noqa: E402
    Course,
    EnrollmentStatusType,
    School,
    Session,
    StudentCourse,
)
from students.models import StudentSubmission  # noqa: E402
from users.models import CustomUser, UserTypes  # noqa: E402

random.seed(20260914)
T = int(sys.argv[1])
SCHOOLS, COURSES_PER_TEACHER, STUDENTS_PER_COURSE, ASSIGNMENTS_PER_COURSE = 10, 4, 30, 8
# Default 600 keeps the s1/s2 datasets reproducible. At T=60 a 600-student pool
# gives each student ~120 enrolments, which inflates per-student views; pass a
# pool proportional to courses (e.g. 6000) for a realistic ~12.
POOL = int(sys.argv[2]) if len(sys.argv) > 2 else 600
now = timezone.now()
pw = make_password("password123")  # nosec
t0 = time.time()
assert connection.settings_dict["NAME"].startswith("ag_h1_stampede_")
assert CustomUser.objects.count() == 0, "DB already seeded - drop and re-migrate first"


def users(prefix, n, user_type, school=None, superuser=False):
    objs = [
        CustomUser(
            email=f"{prefix}{i}@stampede.test", password=pw, first_name=f"{prefix}{i}",
            last_name="Seed", user_type=user_type, school=school, is_active=True,
            is_superuser=superuser, is_staff=superuser,
            date_joined=now - timedelta(days=random.randint(0, 60)),
        )
        for i in range(n)
    ]
    return CustomUser.objects.bulk_create(objs)


schools = School.objects.bulk_create([School(name=f"Stampede School {s:02d}") for s in range(SCHOOLS)])
users("sup", 1, UserTypes.SUPER_ADMIN, None, superuser=True)
students = users("stu", POOL, UserTypes.STUDENT)
courses, sessions = [], []
for s, school in enumerate(schools):
    users(f"adm{s}-", 1, UserTypes.SCHOOL_ADMIN, school)
    teachers = users(f"tea{s}-", T, UserTypes.TEACHER, school)
    for teacher in teachers:
        sessions.append(Session(name=f"S-{teacher.email}", teacher=teacher))
sessions = Session.objects.bulk_create(sessions)
for session in sessions:
    for c in range(COURSES_PER_TEACHER):
        courses.append(Course(name=f"C{c}-{session.name}", teacher_id=session.teacher_id, session=session))
courses = Course.objects.bulk_create(courses, batch_size=2000)

enrolments, assignments = [], []
for course in courses:
    for student in random.sample(students, STUDENTS_PER_COURSE):
        enrolments.append(StudentCourse(student=student, course=course, enrollment_status=EnrollmentStatusType.ENROLLED))
    for a in range(ASSIGNMENTS_PER_COURSE):
        assignments.append(Assignment(
            title=f"A{a}", course=course, teacher_id=course.teacher_id, status=AssignmentStatus.PUBLISHED,
        ))
StudentCourse.objects.bulk_create(enrolments, batch_size=5000)
assignments = Assignment.objects.bulk_create(assignments, batch_size=5000)

by_course = {}
for e in enrolments:
    by_course.setdefault(e.course_id, []).append(e.student_id)
subs = []
for a in assignments:
    for sid in by_course[a.course_id]:
        if random.random() < 0.30:
            subs.append(StudentSubmission(
                student_id=sid, assignment=a, answers={}, score=60 + random.random() * 40, max_points=100,
                graded_at=now - timedelta(days=random.randint(0, 60)), grading_confidence=0.7 + random.random() * 0.3,
            ))
    if len(subs) >= 20000:
        StudentSubmission.objects.bulk_create(subs, batch_size=5000)
        subs = []
StudentSubmission.objects.bulk_create(subs, batch_size=5000)

print({
    "db": connection.settings_dict["NAME"], "teachers_per_school": T, "student_pool": POOL,
    "enrolments_per_student": round(StudentCourse.objects.count() / POOL, 1),
    "schools": School.objects.count(), "users": CustomUser.objects.count(), "courses": Course.objects.count(),
    "courses_per_school": Course.objects.count() // SCHOOLS, "enrolments": StudentCourse.objects.count(),
    "assignments": Assignment.objects.count(), "submissions": StudentSubmission.objects.count(),
    "seconds": round(time.time() - t0, 1),
})
