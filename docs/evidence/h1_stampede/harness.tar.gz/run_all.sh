#!/usr/bin/env bash
# H-1 post-H-10 stampede measurement orchestrator (NOT for commit).
# Usage: run_all.sh <scale...>   e.g.  run_all.sh s1:6   or   run_all.sh s1:6 s2:60
set -u
S=/tmp/claude-1000/-home-bond-servant-in-training-Documents-Projects-Grade-Automator-Plus/df88a460-0c65-4ec7-9e64-0cfd512fe406/scratchpad/stampede
WT=/home/bond-servant-in-training/Documents/Projects/Grade-Automator-Plus-h1-stampede
EXPECTED=29cc1c778c11793c163ef50daaee6e79ead9ab4b
OUT=$S/results; mkdir -p "$OUT"
cd "$WT"
[ "$(git rev-parse HEAD)" = "$EXPECTED" ] || { echo "ABORT: worktree not at $EXPECTED"; exit 1; }
[ -z "$(git status --porcelain)" ] || { echo "ABORT: worktree dirty"; exit 1; }
# Both on the path: $S for the harness modules and settings shim, $WT for the
# project. A script run by path gets ITS directory on sys.path, not the cwd.
export PYTHONPATH=$S:$WT DJANGO_SETTINGS_MODULE=stampede_settings
export STAMPEDE_REDIS="redis://127.0.0.1:6390/0"
PORT=18765

# Dedicated, non-persistent Redis: nothing else writes to it, so SET counts are attributable.
if ! redis-cli -p 6390 ping >/dev/null 2>&1; then
  redis-server --port 6390 --bind 127.0.0.1 --save "" --appendonly no --daemonize yes \
    --pidfile $S/redis6390.pid --logfile $S/redis6390.log
  sleep 1
fi
echo "redis 6390: $(redis-cli -p 6390 ping)"

for SCALE in "$@"; do
  NAME=${SCALE%%:*}; T=${SCALE##*:}
  export STAMPEDE_DB="postgresql://postgres:Nkopuruk%404@127.0.0.1:5432/ag_h1_stampede_$NAME"
  echo "===== $NAME (teachers/school=$T) $(date -Is)"
  python $S/seed.py "$T" > "$OUT/seed_$NAME.txt" 2>&1; SEED_RC=$?
  tail -3 "$OUT/seed_$NAME.txt"
  [ $SEED_RC -eq 0 ] || { echo "ABORT $NAME: seed failed (exit $SEED_RC)"; continue; }
  redis-cli -p 6390 flushall >/dev/null
  STAMPEDE_LABEL="$NAME" STAMPEDE_OUT="$OUT/cost.jsonl" python $S/measure_cost.py > "$OUT/cost_$NAME.log" 2>&1
  COST_RC=$?; echo "cost harness exit=$COST_RC $(date -Is)"
  [ $COST_RC -eq 0 ] || { echo "ABORT $NAME: cost harness failed"; continue; }
  redis-cli -p 6390 flushall >/dev/null
  redis-cli -p 6390 config resetstat >/dev/null
  gunicorn AutoGrader.wsgi:application --bind 127.0.0.1:$PORT --timeout 100 --workers 9 --threads 4 \
    --worker-class gthread --keep-alive 5 --pid $S/gunicorn.pid --log-file $OUT/gunicorn_$NAME.log --daemon
  for i in $(seq 1 60); do curl -s -o /dev/null http://127.0.0.1:$PORT/ 2>/dev/null && break; sleep 1; done
  echo "gunicorn up: http $(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:$PORT/api/v1/)"
  STAMPEDE_URL="http://127.0.0.1:$PORT" STAMPEDE_LABEL="$NAME" STAMPEDE_OUT="$OUT/stampede.jsonl" \
    python $S/measure_stampede.py > "$OUT/stampede_$NAME.log" 2>&1
  echo "stampede harness exit=$? $(date -Is)"
  kill "$(cat $S/gunicorn.pid)"; sleep 3
  redis-cli -p 6390 flushall >/dev/null
done

redis-cli -p 6390 shutdown nosave >/dev/null 2>&1
echo "DONE $(date -Is)"
