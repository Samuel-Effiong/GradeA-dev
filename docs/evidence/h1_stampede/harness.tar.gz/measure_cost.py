"""Harness A: in-process cold-rebuild cost per cached family (NOT for commit).

For each family: 5 cold builds (generation bumped before each, so the read is
a genuine miss through the real versioned key) -> p50/max wall ms and query
count; then 5 warm reads -> p50. Output JSONL to $STAMPEDE_OUT.
"""
import json
import os
import statistics
import sys
import time

import django

django.setup()

from django.core.cache import cache  # noqa: E402
from django.db import connection  # noqa: E402
from django.test import Client  # noqa: E402
from django.test.utils import CaptureQueriesContext  # noqa: E402
from rest_framework_simplejwt.tokens import AccessToken  # noqa: E402

sys.path.insert(0, os.path.dirname(__file__))
from targets import fixtures, targets  # noqa: E402

from AutoGrader.cache_generation import bump_many  # noqa: E402

LABEL = os.environ["STAMPEDE_LABEL"]
OUT = os.environ["STAMPEDE_OUT"]
cache.clear()
f = fixtures()
client = Client()
for label, user, path, scopes in targets(f):
    auth = {"HTTP_AUTHORIZATION": f"Bearer {AccessToken.for_user(user)}"}
    client.get(path, **auth)  # warm imports / connection
    colds, queries, status = [], [], None
    for _ in range(5):
        bump_many(scopes)
        with CaptureQueriesContext(connection) as ctx:
            t0 = time.perf_counter()
            r = client.get(path, **auth)
            colds.append((time.perf_counter() - t0) * 1000)
        queries.append(len(ctx.captured_queries))
        status = r.status_code
    warms = []
    for _ in range(5):
        t0 = time.perf_counter()
        client.get(path, **auth)
        warms.append((time.perf_counter() - t0) * 1000)
    row = {
        "label": LABEL, "family": label, "status": status,
        "cold_p50_ms": round(statistics.median(colds), 1), "cold_max_ms": round(max(colds), 1),
        "warm_p50_ms": round(statistics.median(warms), 1), "queries": statistics.median(queries),
    }
    print(json.dumps(row), flush=True)
    with open(OUT, "a") as fh:
        fh.write(json.dumps(row) + "\n")
