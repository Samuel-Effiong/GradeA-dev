"""Shared: every cached family to measure, with the user and scope that
invalidates it. Resolved against whatever DB the settings point at."""
from django.urls import reverse

from assignments.models import Assignment
from AutoGrader.cache_generation import (
    SCOPE_ANY_SCHOOL,
    SCOPE_ANY_USER,
    SCOPE_GLOBAL,
    SCOPE_SCHOOL,
    SCOPE_USER,
)
from classrooms.models import Course, School, Session
from users.models import CustomUser, UserTypes


def fixtures():
    school = School.objects.order_by("name").first()
    admin = CustomUser.objects.get(school=school, user_type=UserTypes.SCHOOL_ADMIN)
    teacher = CustomUser.objects.filter(school=school, user_type=UserTypes.TEACHER).order_by("email").first()
    sup = CustomUser.objects.get(user_type=UserTypes.SUPER_ADMIN)
    session = Session.objects.filter(teacher=teacher).first()
    course = Course.objects.filter(teacher=teacher).order_by("name").first()
    assignment = Assignment.objects.filter(course=course).first()
    student = course.enrollments.select_related("student").first().student
    return dict(school=school, admin=admin, teacher=teacher, sup=sup, session=session,
                course=course, assignment=assignment, student=student)


def targets(f):
    """(label, user, path, scopes that invalidate it)."""
    sa = "/api/v1/super-admin/dashboard/"
    sc = "/api/v1/school-admin/dashboard/"
    ta = "/api/v1/teacher-admin/dashboard/"

    def usr(u):
        return [(SCOPE_USER, u.id)]

    sch = [(SCOPE_SCHOOL, f["school"].id)]
    out = [
        ("15 sa adoption", f["sup"], sa + "adoption", [(SCOPE_GLOBAL, None)]),
        ("16 sa usage", f["sup"], sa + "usage", [(SCOPE_GLOBAL, None)]),
        ("17 sa ai_performance", f["sup"], sa + "ai_performance", [(SCOPE_GLOBAL, None)]),
        ("18 sa scaling_signals", f["sup"], sa + "scaling_signals", [(SCOPE_GLOBAL, None)]),
        ("19 sa schools", f["sup"], sa + "schools", [(SCOPE_ANY_SCHOOL, None)]),
        ("20 sa teachers", f["sup"], sa + "teachers", [(SCOPE_ANY_USER, None)]),
        ("21 sa students", f["sup"], sa + "students", [(SCOPE_GLOBAL, None)]),
        ("23 sch summary", f["admin"], sc + "summary", sch),
        ("24 sch at-risk-trend", f["admin"], sc + "at-risk-trend", sch),
        ("25 sch students", f["admin"], sc + "students", sch),
        ("30 sch teacher_performance", f["admin"], sc + "teachers", sch),
        ("31 sch teacher_detail", f["admin"], sc + f"teachers/{f['teacher'].id}", sch),
        ("32 sch assignment_activity", f["admin"], sc + "assignment-activity-over-time", sch),
        ("33 sch department_overview", f["admin"], sc + "course-overview-chart", sch),
        ("26 ta overview", f["teacher"], ta + f"overview/{f['session'].id}", usr(f["teacher"])),
        ("27 ta courses", f["teacher"], ta + f"courses/{f['course'].id}", usr(f["teacher"])),
        ("28 ta assignments", f["teacher"], ta + f"assignments/{f['assignment'].id}", usr(f["teacher"])),
        ("29 ta students", f["teacher"], ta + f"students/{f['course'].id}", usr(f["teacher"])),
        ("11 my_courses (student)", f["student"], reverse("course-my-courses"), [(SCOPE_GLOBAL, None)]),
        ("mixin course-list (teacher)", f["teacher"], reverse("course-list"), usr(f["teacher"])),
        ("mixin session-list (teacher)", f["teacher"], reverse("session-list"), usr(f["teacher"])),
        ("mixin student-course-list (teacher)", f["teacher"], reverse("student-course-list"), usr(f["teacher"])),
        ("mixin submission-list (teacher)", f["teacher"], reverse("student-submission-list"), usr(f["teacher"])),
    ]
    try:
        out.append(("mixin assignment-list (teacher)", f["teacher"], reverse("assignment-list"), usr(f["teacher"])))
    except Exception:  # nosec - route name may not exist
        pass
    return out
