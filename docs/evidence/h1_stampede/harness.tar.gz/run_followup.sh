#!/usr/bin/env bash
# H-1 stampede follow-up (NOT for commit). Run only after run_all.sh has finished.
#   1. create + migrate + seed s3: 240 courses/school with a REALISTIC student pool
#      (6000 students, ~12 enrolments each), so per-student views aren't inflated
#   2. harness C (warm vs cold bursts) on the expensive families at s1, s2, s3
#   3. harness A (rebuild cost) at s3
set -u
S=/tmp/claude-1000/-home-bond-servant-in-training-Documents-Projects-Grade-Automator-Plus/df88a460-0c65-4ec7-9e64-0cfd512fe406/scratchpad/stampede
WT=/home/bond-servant-in-training/Documents/Projects/Grade-Automator-Plus-h1-stampede
EXPECTED=29cc1c778c11793c163ef50daaee6e79ead9ab4b
OUT=$S/results; mkdir -p "$OUT"
cd "$WT"
[ "$(git rev-parse HEAD)" = "$EXPECTED" ] && [ -z "$(git status --porcelain)" ] || { echo "ABORT: worktree not clean at $EXPECTED"; exit 1; }
export PGPASSWORD='Nkopuruk@4'
PSQL="psql -h 127.0.0.1 -U postgres -Atc"
export PYTHONPATH=$S:$WT DJANGO_SETTINGS_MODULE=stampede_settings
export STAMPEDE_REDIS="redis://127.0.0.1:6390/0"
PORT=18765
FAMILIES="23 sch summary,11 my_courses (student),16 sa usage,21 sa students,26 ta overview"

ss -ltn 2>/dev/null | grep -q ":$PORT " && { echo "ABORT: port $PORT in use"; exit 1; }
if ! redis-cli -p 6390 ping >/dev/null 2>&1; then
  redis-server --port 6390 --bind 127.0.0.1 --save "" --appendonly no --daemonize yes \
    --pidfile $S/redis6390.pid --logfile $S/redis6390.log
  sleep 1
fi
echo "redis 6390: $(redis-cli -p 6390 ping)"

echo "===== s3 setup $(date -Is)"
$PSQL "drop database if exists ag_h1_stampede_s3" >/dev/null
$PSQL "create database ag_h1_stampede_s3" >/dev/null
export STAMPEDE_DB="postgresql://postgres:Nkopuruk%404@127.0.0.1:5432/ag_h1_stampede_s3"
python manage.py migrate --noinput > "$OUT/migrate_s3.log" 2>&1; MIG=$?
echo "s3 migrate exit=$MIG applied=$(grep -c '  Applying ' "$OUT/migrate_s3.log")"
if [ $MIG -eq 0 ]; then
  python $S/seed.py 60 6000 > "$OUT/seed_s3.txt" 2>&1; SEED=$?
  tail -1 "$OUT/seed_s3.txt"
  if [ $SEED -eq 0 ]; then
    redis-cli -p 6390 flushall >/dev/null
    STAMPEDE_LABEL="s3" STAMPEDE_OUT="$OUT/cost.jsonl" python $S/measure_cost.py > "$OUT/cost_s3.log" 2>&1
    echo "s3 cost harness exit=$? $(date -Is)"
  else
    echo "ABORT s3: seed failed (exit $SEED)"
  fi
fi

for NAME in s1 s2 s3; do
  export STAMPEDE_DB="postgresql://postgres:Nkopuruk%404@127.0.0.1:5432/ag_h1_stampede_$NAME"
  [ "$($PSQL "select count(*) from pg_database where datname='ag_h1_stampede_$NAME'")" = 1 ] || { echo "skip $NAME: no DB"; continue; }
  echo "===== warm-vs-cold $NAME $(date -Is)"
  redis-cli -p 6390 flushall >/dev/null
  gunicorn AutoGrader.wsgi:application --bind 127.0.0.1:$PORT --timeout 100 --workers 9 --threads 4 \
    --worker-class gthread --keep-alive 5 --pid $S/gunicorn_fu.pid --log-file $OUT/gunicorn_fu_$NAME.log --daemon
  for i in $(seq 1 60); do curl -s -o /dev/null http://127.0.0.1:$PORT/ 2>/dev/null && break; sleep 1; done
  echo "gunicorn up ($NAME): http $(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:$PORT/api/v1/)"
  STAMPEDE_URL="http://127.0.0.1:$PORT" STAMPEDE_LABEL="$NAME" STAMPEDE_OUT="$OUT/warm_vs_cold.jsonl" \
    STAMPEDE_FAMILIES="$FAMILIES" STAMPEDE_N=50 STAMPEDE_ROUNDS=5 \
    python $S/measure_warm_vs_cold.py > "$OUT/warm_vs_cold_$NAME.log" 2>&1
  echo "warm-vs-cold harness exit=$? ($NAME) $(date -Is)"
  kill "$(cat $S/gunicorn_fu.pid)"; sleep 3
done

redis-cli -p 6390 shutdown nosave >/dev/null 2>&1
echo "FOLLOWUP DONE $(date -Is)"
