# H-145 chain: every run and the one-sentence cause of each stop

1. First run, tip ffd1f6c1, 19:11:28 to 19:14:54 (`first_run_ffd1f6c1/`): stopped at (a): the route test queued two tasks with one fake celery id (a unique-key 500 from the database); it failed in set-up at (r) and at (a) and had never reached its assertion.
2. Second run, tip 76b69102, 19:42:55 to 19:43:19 (`second_stop_76b69102/`): stopped at (r): my written red set still listed a test that has been a control since c7d28c13 (it passes on the old code), found because (r) now takes the tip's module.
3. Third run, tip 76b69102, 19:55:24 to 20:01:36: GREEN, no stop.
Lesson in both: a red set matched by test NAME is not a red for its own reason (rule 22), and a written set must be re-read after every amendment of the tests.
