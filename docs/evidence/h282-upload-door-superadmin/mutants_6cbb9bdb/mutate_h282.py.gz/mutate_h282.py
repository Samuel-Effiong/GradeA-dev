import hashlib, pathlib, re, subprocess, sys
W = pathlib.Path(sys.argv[1]); PY = sys.argv[2]; OUT = pathlib.Path(sys.argv[3]); LABELS = sys.argv[4].split()
ONLY = sys.argv[5:]
OUT.mkdir(exist_ok=True)
C = "6cbb9bdb9"
UM, UD = "users/models.py", "assignments/upload_door.py"
# (path, line or None, old, new); a line pins a duplicate text to one site.
M = {
 "M-h282.1": [(UM, 196, "self.is_superuser and ", "")],
 "M-h282.2": [(UM, 196, " and self.user_type == UserTypes.SUPER_ADMIN", "")],
 "M-h282.3": [(UD, 87, "request_user.is_real_super_admin()", "request_user.user_type == UserTypes.SUPER_ADMIN")],
 "M-h282.4": [(UD, 121, "request_user.is_real_super_admin()", "request_user.user_type == UserTypes.SUPER_ADMIN")],
 "M-h282.5": [(UD, 87, "request_user.is_real_super_admin()", "False")],
 "M-h282.6": [(UD, 121, "request_user.is_real_super_admin()", "False")],
}
files = sorted({p for e in M.values() for p, _, _, _ in e})
committed = {p: subprocess.run(["git", "-C", str(W), "show", f"{C}:{p}"], capture_output=True, check=True).stdout for p in files}
SHA = {p: hashlib.sha256(b).hexdigest() for p, b in committed.items()}
sha = lambda p: hashlib.sha256((W / p).read_bytes()).hexdigest()
for p in files:
    assert sha(p) == SHA[p], p
print("committed sha256:", {p: SHA[p][:12] for p in files}, flush=True)

def apply(src, line, old, new):
    lines = src.splitlines(keepends=True)
    if line is None:
        assert src.count(old) == 1, (old, src.count(old))
        return src.replace(old, new, 1)
    if old.endswith("\n"):
        assert lines[line - 1] == old, (line, lines[line - 1])
        lines[line - 1] = new
    else:
        assert lines[line - 1].count(old) == 1, (line, lines[line - 1])
        lines[line - 1] = lines[line - 1].replace(old, new, 1)
    return "".join(lines)

for name, edits in M.items():
    if ONLY and name not in ONLY:
        continue
    touched = sorted({p for p, _, _, _ in edits})
    try:
        for p, line, old, new in edits:
            (W / p).write_text(apply((W / p).read_text(), line, old, new))
        r = subprocess.run([PY, "manage.py", "test", "--noinput", "--settings=settings_worktree", "-v", "2", *LABELS],
                           cwd=W, capture_output=True, text=True, timeout=3600)
        log = r.stdout + r.stderr; rc = r.returncode
    finally:
        for p in touched:
            (W / p).write_bytes(committed[p])
    for p in touched:
        assert sha(p) == SHA[p], "restore failed " + p
    head = "".join(f"{name}: {p}:{line}\n- {old!r}\n+ {new!r}\n" for p, line, old, new in edits)
    (OUT / f"{name}.txt").write_text(f"{head}rc={rc}\nrestored sha256 {', '.join(SHA[p] for p in touched)}\n\n" + log)
    hits = sorted({re.sub(r"^(FAIL|ERROR): (\S+) \(([^)]*)\).*", r"\3", l) for l in log.splitlines() if l.startswith(("FAIL:", "ERROR:"))})
    tail = [l for l in log.splitlines() if l.startswith(("Ran ", "OK", "FAILED"))]
    print(name, "rc=%d" % rc, "restored ok", tail, flush=True)
    for h in hits:
        print("   ", h, flush=True)
