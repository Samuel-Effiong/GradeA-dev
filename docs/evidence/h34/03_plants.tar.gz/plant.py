"""H-34 plant harness: copy, mutate, sha check, run, restore, sha check.

Usage (from the worktree root): python plant.py <PLANT_ID> <log_path>
"""

import hashlib
import shutil
import subprocess
import sys

P2_BLOCK = '''        if user:
            user.reset_login_lockout()
'''
P2_MOVED = '''        if user and user.is_admin_locked:
            raise EnvelopedAuthenticationFailed(
                lock_message(user),
                "ACCOUNT_LOCKED_BY_ADMIN",
                reason_code="ACCOUNT_LOCKED_BY_ADMIN",
                code_value="ACCOUNT_LOCKED_BY_ADMIN",
            )

        if user:
            user.reset_login_lockout()
'''

PLANTS = {
    "Q-P1": ("users/sign_in_lock.py", [
        ('                token_epoch=F("token_epoch") + 1,\n', ""),
    ]),
    "Q-P2": ("users/serializers.py", [
        ("        if user and user.is_admin_locked:\n            emit(",
         "        if False:\n            emit("),
        (P2_BLOCK, P2_MOVED),
    ]),
    "Q-P3": ("users/views.py", [
        ('                    if user.is_admin_locked:\n'
         '                        self._audit_reason = "ACCOUNT_LOCKED_BY_ADMIN"',
         '                    if False:\n'
         '                        self._audit_reason = "ACCOUNT_LOCKED_BY_ADMIN"'),
    ]),
    "Q-P4": ("users/views.py", [
        ("        if user.is_admin_locked:\n            if not otp_obj.is_locked():",
         "        if False:\n            if not otp_obj.is_locked():"),
    ]),
    "Q-P5": ("users/authentication.py", [
        ('if cast("CustomUser", user).is_admin_locked:', "if False:"),
    ]),
    "Q-P6": ("users/sign_in_lock.py", [
        ("                failed_login_attempts=0,\n", ""),
    ]),
    "Q-P7": ("users/sign_in_lock.py", [
        ("    return target.pk != actor.pk and not is_super_admin_account(target)",
         "    return target.pk != actor.pk"),
        ("        .exclude(is_superuser=True)\n"
         "        .exclude(user_type=UserTypes.SUPER_ADMIN)\n", ""),
    ]),
    "Q-P8": ("users/sign_in_lock.py", [
        ("    return target.pk != actor.pk and not is_super_admin_account(target)",
         "    return not is_super_admin_account(target)"),
        ("        .exclude(pk=actor.pk)\n", ""),
    ]),
    "Q-P9": ("users/sign_in_lock.py", [
        ("                locked_until=None,\n            )",
         "                locked_until=None,\n                is_active=True,\n            )"),
    ]),
    "R3-i": ("audit/admin_action.py", [
        ("        if hasattr(raw, REQUEST_ATTR):\n            delattr(raw, REQUEST_ATTR)",
         "        pass"),
    ]),
    "R3-ii": ("audit/admin_action.py", [
        ("    event = emit(action, actor=request.user, request=request, **fields)",
         "    event = object()"),
    ]),
}

LABELS = [
    "users.tests_admin_sign_in_lock",
    "audit.tests_route_coverage.AdminSignInLockRouteTests",
]


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def main():
    plant, log = sys.argv[1], sys.argv[2]
    path, edits = PLANTS[plant]
    saved = f"{log}.{path.replace('/', '_')}.orig"
    shutil.copyfile(path, saved)
    original = sha(path)
    committed = subprocess.run(
        ["git", "show", f"HEAD:{path}"], capture_output=True, check=True
    ).stdout
    assert hashlib.sha256(committed).hexdigest() == original, "file differs from HEAD"
    text = open(path).read()
    for old, new in edits:
        assert text.count(old) == 1, (plant, old[:60])
        text = text.replace(old, new)
    open(path, "w").write(text)
    planted = sha(path)
    print(f"{plant} {path} original {original}")
    print(f"{plant} {path} planted  {planted}")
    assert planted != original
    try:
        with open(log, "w") as out:
            subprocess.run(
                ["flock", "/home/bond-servant-in-training/.machine-fullsuite.lock",
                 sys.executable, "manage.py", "test", *LABELS,
                 "--settings=settings_worktree", "--keepdb", "--noinput", "-v", "2"],
                stdout=out, stderr=subprocess.STDOUT,
            )
    finally:
        shutil.copyfile(saved, path)
        restored = sha(path)
        print(f"{plant} {path} restored {restored} {'OK' if restored == original else 'MISMATCH'}")
        assert restored == original


if __name__ == "__main__":
    main()
