"""v2's probe for H-203 (THE PRINCIPLE on the Google, school-admin invitation and add-by-email roads), written
2026-10-09 BEFORE any run, at 578b5ce4. Copy to users/tests_vf2_h203_probe.py of the scratch worktree; never
committed to the branch.

THE PRINCIPLE (users/admin_power.py): an account with admin power that has never been verified can be entered
only with its password; no road that proves only control of a mailbox signs it in, verifies it or activates it.
d5's tests call the add-by-email road as a SERVICE; mine go through the real ROUTES (the course `students` action
and `direct-add-student`) and compare WHOLE rows before and after (every column), not three chosen ones.

Class VF2Google (route auth/google-auth, Google's two calls replaced):
  g1  a never-verified, INACTIVE admin-power account is refused (400), not activated, not verified, nothing written
  g2  the refusal answers byte for byte as an ordinary failed Google sign-in does
  g3  the refusal leaves the whole row as it was and issues no token (no OutstandingToken row)
  g4  control: a VERIFIED, switched-off admin-power account gets the existing carve-out (401), nothing written
Class VF2Invitation (route auth/register/school-admin):
  i1  a pending row carrying is_superuser is refused with the wrong-token answer, whole row untouched
Class VF2AddStudentRoutes (course `students` action and `direct-add-student`, a teacher's real session):
  a1/a2  a STUDENT-typed row with is_staff / is_superuser: 400 with the neutral not-a-student answer, whole row
         untouched, no enrolment made, no invitation mail
  a3  the same through direct-add-student
  a4  control: an ordinary student is added through the same route (200, one enrolment)
  a5  a verified, switched-off STUDENT-typed row with admin power: the not-a-student answer (the admin-power gate
      comes before the deactivated one), whole row untouched
Class VF2LicenceRoadFindings (report-only; l1 is PREDICTED RED):
  l1  billing.license_service.LicenseSubscriptionService._get_or_invite_teacher on an EXISTING TEACHER-typed row
      with is_staff, never verified, must_change_password True: by the principle its password must not be
      replaced and no password mailed. This road is not on the author's list of roads.
Rule 19, which mutant shows which probe red: g1 under R2; g2 under R8; g3/g1 under R1; i1 under R3, R6;
a1..a3, a5 under R4; a2/i1 under R6.
"""
from datetime import timedelta
from unittest.mock import patch

import requests
from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.forms.models import model_to_dict
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase
from rest_framework_simplejwt.token_blacklist.models import OutstandingToken

from classrooms.models import Course, School, Session, StudentCourse
from classrooms.services.enrollment import NOT_A_STUDENT_MESSAGE
from users.models import UserTypes

User = get_user_model()
LOCMEM = {"default": {"BACKEND": "django.core.cache.backends.locmem.LocMemCache"}}
GOOGLE_FAILED = "Google sign-in failed. Please try again."
STRONG = "a-strong-passphrase-for-vf2-h203"  # pragma: allowlist secret


def whole_row(user):
    """Every column of the row as stored now, read fresh."""
    return model_to_dict(User.objects.get(pk=user.pk))


@override_settings(CACHES=LOCMEM)
class VF2Google(APITestCase):
    def setUp(self):
        cache.clear()
        self.addCleanup(cache.clear)
        self.url = reverse("auth-google-auth")
        patcher = patch("users.views.sync_user_to_mailerlite")
        patcher.start()
        self.addCleanup(patcher.stop)

    def call(self, email, token_exchange_fails=False):
        with patch("requests.post") as mocked_post, patch("users.views.id_token.verify_oauth2_token") as mocked_verify:
            if token_exchange_fails:
                mocked_post.side_effect = requests.exceptions.ConnectionError("google is down")
            else:
                mocked_post.return_value.raise_for_status.return_value = None
                mocked_post.return_value.json.return_value = {
                    "id_token": "fake-id-token", "access_token": "fake-access-token",
                    "refresh_token": "fake-refresh-token", "expires_in": 3600,
                }
            mocked_verify.return_value = {"email": email, "email_verified": True,
                                          "given_name": "Google", "family_name": "Person"}
            return self.client.post(self.url, {"code": "oauth-code"}, format="json")

    def account(self, email, verified, active, **flags):
        flags.setdefault("user_type", UserTypes.TEACHER)
        return User.objects.create_user(email=email, password="Google-pass-vf2",  # pragma: allowlist secret
                                        is_active=active,
                                        email_verified_at=timezone.now() if verified else None, **flags)

    def test_g1_a_never_verified_inactive_admin_power_account_is_refused_and_left_alone(self):
        account = self.account("vf2-g1@x.example", verified=False, active=False, is_staff=True)
        before = whole_row(account)

        response = self.call(account.email)

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertNotIn("access", response.data)
        self.assertEqual(whole_row(account), before)
        self.assertIs(before["is_active"], False)
        self.assertIsNone(before["email_verified_at"])

    def test_g2_the_refusal_is_the_same_bytes_as_an_ordinary_failed_google_sign_in(self):
        account = self.account("vf2-g2@x.example", verified=False, active=True, is_superuser=True)
        failed = self.call("nobody-vf2@x.example", token_exchange_fails=True)
        self.assertEqual(failed.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn(GOOGLE_FAILED, str(failed.data))

        refused = self.call(account.email)

        self.assertEqual(refused.status_code, failed.status_code)
        self.assertEqual(refused.content, failed.content)

    def test_g3_the_refusal_changes_no_column_and_issues_no_token(self):
        account = self.account("vf2-g3@x.example", verified=False, active=True, user_type=UserTypes.SUPER_ADMIN)
        before = whole_row(account)
        tokens = OutstandingToken.objects.count()

        response = self.call(account.email)

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(whole_row(account), before)
        self.assertEqual(OutstandingToken.objects.count(), tokens)

    def test_g4_control_a_verified_switched_off_admin_power_account_gets_the_existing_carve_out(self):
        account = self.account("vf2-g4@x.example", verified=True, active=False, is_staff=True, is_superuser=True,
                               user_type=UserTypes.SUPER_ADMIN)
        before = whole_row(account)

        response = self.call(account.email)

        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
        self.assertEqual(whole_row(account), before)
        self.assertIsNotNone(before["email_verified_at"])


@override_settings(CACHES=LOCMEM)
class VF2Invitation(APITestCase):
    def setUp(self):
        cache.clear()
        self.addCleanup(cache.clear)
        patcher = patch("users.views.sync_user_to_mailerlite")
        patcher.start()
        self.addCleanup(patcher.stop)
        self.school = School.objects.create(name="VF2 H203 Admin High")
        self.url = reverse("auth-register-school-admin")

    def test_i1_a_pending_row_carrying_is_superuser_gets_the_wrong_token_answer_and_is_left_alone(self):
        user = User.objects.create_user(
            email="vf2-i1@x.example", password="Pending-pass-vf2",  # pragma: allowlist secret
            user_type=UserTypes.SCHOOL_ADMIN, school=self.school, is_active=False, is_superuser=True,
            activation_token="vf2-invite-token", activation_expires=timezone.now() + timedelta(days=1))
        before = whole_row(user)
        wrong = self.client.post(self.url, {"email": user.email, "token": "not-the-token", "password": STRONG},
                                 format="json")
        self.assertEqual(wrong.status_code, status.HTTP_400_BAD_REQUEST)

        refused = self.client.post(self.url, {"email": user.email, "token": "vf2-invite-token", "password": STRONG},
                                   format="json")

        self.assertEqual(refused.status_code, wrong.status_code)
        self.assertEqual(refused.content, wrong.content)
        self.assertNotIn("access", refused.data)
        self.assertEqual(whole_row(user), before)


class VF2AddStudentRoutes(APITestCase):
    def setUp(self):
        for target in ("classrooms.services.notifications.safe_delay", "users.views.send_user_activation_email"):
            patcher = patch(target)
            patcher.start()
            self.addCleanup(patcher.stop)
        invite = patch("classrooms.services.notifications.send_student_login_invitation_email")
        self.invite_mail = invite.start()
        self.addCleanup(invite.stop)
        added = patch("classrooms.services.notifications.send_added_to_course_email")
        self.added_mail = added.start()
        self.addCleanup(added.stop)
        school = School.objects.create(name="VF2 H203 Add High")
        self.teacher = User.objects.create_user(
            email="vf2.teacher@add-high.example", password="Teacher-pass-vf2",  # pragma: allowlist secret
            user_type=UserTypes.TEACHER, school=school, is_active=True)
        session = Session.objects.create(name="Term", teacher=self.teacher)
        self.course = Course.objects.create(name="Maths", teacher=self.teacher, session=session)
        self.client.force_authenticate(self.teacher)

    def row(self, email, **fields):
        fields.setdefault("is_active", True)
        return User.objects.create_user(email=email, password="Student-pass-vf2",  # pragma: allowlist secret
                                        user_type=UserTypes.STUDENT, **fields)

    def add_by_email(self, email):
        return self.client.post(reverse("course-students", args=[self.course.pk]),
                                {"email": email, "first_name": "Typed", "last_name": "Name"}, format="json")

    def assert_refused_untouched(self, response, account, before, direct_add=False):
        if direct_add:
            # Status NOT pinned to 400 because of H-214 (known, not H-203): the direct-add route answers 500 for
            # a refused add (a DRF ValidationError swallowed by `except Exception`). Any 4xx/5xx is a refusal here;
            # what matters for H-203 is asserted below: row untouched, no enrolment, no mail.
            self.assertGreaterEqual(response.status_code, 400)
        else:
            self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
            self.assertIn(NOT_A_STUDENT_MESSAGE, str(response.data))
        self.assertEqual(whole_row(account), before)
        self.assertFalse(StudentCourse.objects.filter(student=account).exists())
        self.invite_mail.assert_not_called()
        self.added_mail.assert_not_called()

    def test_a1_add_by_email_refuses_a_student_typed_row_carrying_is_staff(self):
        account = self.row("vf2-a1@x.example", is_staff=True)
        before = whole_row(account)
        self.assert_refused_untouched(self.add_by_email(account.email), account, before)

    def test_a2_add_by_email_refuses_a_student_typed_row_carrying_is_superuser(self):
        account = self.row("vf2-a2@x.example", is_superuser=True)
        before = whole_row(account)
        self.assert_refused_untouched(self.add_by_email(account.email), account, before)

    def test_a3_direct_add_refuses_the_same_rows(self):
        account = self.row("vf2-a3@x.example", is_staff=True)
        before = whole_row(account)

        response = self.client.post(reverse("course-direct-add-student", args=[self.course.pk]),
                                    {"first_name": "Typed", "last_name": "Name", "email": account.email},
                                    format="json")

        self.assert_refused_untouched(response, account, before, direct_add=True)

    def test_a4_control_an_ordinary_student_is_added_through_the_same_route(self):
        account = self.row("vf2-a4@x.example")

        response = self.add_by_email(account.email)

        self.assertEqual(response.status_code, status.HTTP_200_OK, getattr(response, "data", None))
        self.assertEqual(StudentCourse.objects.filter(student=account, course=self.course).count(), 1)

    def test_a5_a_verified_switched_off_row_with_admin_power_gets_the_not_a_student_answer(self):
        account = self.row("vf2-a5@x.example", is_active=False, is_staff=True, email_verified_at=timezone.now())
        before = whole_row(account)
        self.assert_refused_untouched(self.add_by_email(account.email), account, before)


class VF2LicenceRoadFindings(TestCase):
    def test_l1_the_licence_teacher_road_does_not_replace_the_password_of_an_unverified_admin_power_row(self):
        from billing.license_service import LicenseSubscriptionService

        school = School.objects.create(name="VF2 Licence School")
        admin = User.objects.create_user(email="vf2-school-admin@licence-school.example",
                                         password="Admin-pass-vf2",  # pragma: allowlist secret
                                         user_type=UserTypes.SCHOOL_ADMIN, school=school, is_active=True)
        row = User.objects.create_user(email="vf2-teacher-staff@licence-school.example",
                                       password="Teacher-pass-vf2",  # pragma: allowlist secret
                                       user_type=UserTypes.TEACHER, is_staff=True, is_active=True,
                                       must_change_password=True, email_verified_at=None)
        before = whole_row(row)

        with patch("billing.license_service.is_business_email", return_value=True), \
                patch("billing.license_service.is_exempt_email_domain", return_value=False), \
                patch.object(LicenseSubscriptionService, "_send_teacher_invitation") as mailed:
            LicenseSubscriptionService._get_or_invite_teacher(row.email, school, admin)

        mail_count = mailed.call_count
        after = whole_row(row)
        self.assertEqual(mail_count, 0)
        self.assertEqual(after["password"], before["password"])
