"""1a's own tests for H-203, Google road (rule 19 and rule 22).

The author's Google tests assert the PERSISTED state after a refusal. The
refusal sits inside `with transaction.atomic()`, so a write that happens before
the refusal is rolled back and no persisted-state test can see it (his notes T8
and T20). These tests look at what an atomic block does NOT undo: the queued
sync to the mailing list (safe_delay), the sign-in stamp, the stored Google
credentials, and the token. One test per shape of account.

v0  control: an ordinary never-verified account signs in with Google (200,
    stamped verified). Shows the harness reaches the existing-account branch.
v1  a never-verified account with admin power (four shapes: is_staff on an
    active TEACHER row, is_superuser on an inactive row, user type SUPER_ADMIN,
    the create_superuser shape) is refused with the failed-sign-in answer, and
    nothing leaves the transaction: no safe_delay, no stamp_last_login, no
    UserGoogleCredentials row, no token, the row unchanged.
v3  control: a VERIFIED, active account with is_staff signs in (200): the
    principle is about never-verified accounts only.

Copied to users/tests_vf1a_h203.py of a scratch checkout.
"""

from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.core.cache import cache
from django.test import override_settings
from django.urls import reverse
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from users.models import UserGoogleCredentials, UserTypes

User = get_user_model()
LOCMEM_CACHE = {"default": {"BACKEND": "django.core.cache.backends.locmem.LocMemCache"}}
PASSWORD = "password123"  # pragma: allowlist secret


@override_settings(CACHES=LOCMEM_CACHE)
class VF1aH203(APITestCase):
    def setUp(self):
        cache.clear()
        self.addCleanup(cache.clear)
        self.url = reverse("auth-google-auth")

    def _google(self, email):
        token = {
            "id_token": "fake-id-token",
            "access_token": "fake-access-token",
            "refresh_token": "fake-refresh-token",
            "expires_in": 3600,
        }
        info = {
            "email": email,
            "email_verified": True,
            "given_name": "Vf",
            "family_name": "One",
        }
        with patch("requests.post") as post, patch(
            "users.views.id_token.verify_oauth2_token"
        ) as verify:
            post.return_value.raise_for_status.return_value = None
            post.return_value.json.return_value = token
            verify.return_value = info
            return self.client.post(self.url, {"code": "oauth-code"}, format="json")

    def _spied_call(self, email):
        with patch("users.views.safe_delay") as queued, patch(
            "users.views.stamp_last_login"
        ) as stamped:
            response = self._google(email)
        return response, queued, stamped

    def test_v0_control_an_ordinary_never_verified_account_signs_in(self):
        user = User.objects.create_user(
            email="vf.control@gmail.com",
            password=PASSWORD,
            user_type=UserTypes.TEACHER,
            is_active=False,
        )

        response, queued, stamped = self._spied_call(user.email)

        self.assertEqual(response.status_code, status.HTTP_200_OK, response.data)
        self.assertIn("access", response.data)
        user.refresh_from_db()
        self.assertIsNotNone(user.email_verified_at)
        self.assertTrue(user.is_active)
        queued.assert_called_once()
        stamped.assert_called_once()
        self.assertEqual(UserGoogleCredentials.objects.filter(user=user).count(), 1)

    def test_v1_a_never_verified_account_with_admin_power_is_refused_and_nothing_leaves(
        self,
    ):
        def staff_teacher(email):
            return User.objects.create_user(
                email=email,
                password=PASSWORD,
                user_type=UserTypes.TEACHER,
                is_staff=True,
                is_active=True,
            )

        def superuser_flag(email):
            return User.objects.create_user(
                email=email,
                password=PASSWORD,
                user_type=UserTypes.TEACHER,
                is_superuser=True,
                is_active=False,
            )

        def super_admin_type(email):
            return User.objects.create_user(
                email=email,
                password=PASSWORD,
                user_type=UserTypes.SUPER_ADMIN,
                is_active=False,
            )

        def command_line_superuser(email):
            return User.objects.create_superuser(email=email, password=PASSWORD)

        shapes = {
            "staff_teacher_active": staff_teacher,
            "superuser_flag_inactive": superuser_flag,
            "super_admin_type_inactive": super_admin_type,
            "command_line_superuser": command_line_superuser,
        }
        for name, make in shapes.items():
            with self.subTest(shape=name):
                user = make(f"vf.{name}@gmail.com")
                self.assertIsNone(user.email_verified_at, "premise: never verified")
                before = (user.is_active, user.password, user.last_login)

                response, queued, stamped = self._spied_call(user.email)

                self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
                self.assertIn(
                    "Google sign-in failed. Please try again.", str(response.data)
                )
                self.assertNotIn("access", response.data)
                self.assertFalse(
                    queued.called,
                    "safe_delay was called before the refusal (not undone by a rollback)",
                )
                self.assertFalse(stamped.called, "the sign-in was stamped")
                self.assertEqual(
                    UserGoogleCredentials.objects.filter(user=user).count(), 0
                )
                user.refresh_from_db()
                self.assertIsNone(user.email_verified_at)
                self.assertEqual((user.is_active, user.password, user.last_login), before)

    def test_v3_control_a_verified_active_staff_account_signs_in(self):
        user = User.objects.create_user(
            email="vf.verified.staff@gmail.com",
            password=PASSWORD,
            user_type=UserTypes.TEACHER,
            is_staff=True,
            is_active=True,
            email_verified_at=timezone.now(),
        )

        response, queued, stamped = self._spied_call(user.email)

        self.assertEqual(response.status_code, status.HTTP_200_OK, response.data)
        self.assertIn("access", response.data)
        stamped.assert_called_once()
