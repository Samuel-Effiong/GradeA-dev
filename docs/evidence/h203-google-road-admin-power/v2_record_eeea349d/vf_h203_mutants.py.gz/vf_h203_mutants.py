"""v2 mutants for H-203 at the tip given in COMMIT (written 2026-10-09 at 578b5ce4, BEFORE any run).
Run from the vf2-s1 scratch worktree detached at COMMIT with users/tests_vf2_h203_probe.py copied in. Usage:
  COMMIT=<sha> MUTANT_LOGS=<dir> python vf_h203_mutants.py check | baseline | findings | mutants
baseline = my three classes (VF2Google, VF2Invitation, VF2AddStudentRoutes) + d5's two modules; expect all green.
findings = VF2LicenceRoadFindings.l1 (PREDICTED RED, report-only). mutants: KILLED = rc != 0 and every named
must-test among the failing (the full failing set is printed); P3 (a new road that sets a password the pin must now see, SM ruling 13:00)
MUST be KILLED after ed's change (on 578b5ce4 it survived: the blind spot). Mutants are located by LINE KEY (a unique line text), not by indentation.
Rule 17: no bytecode, pycache cleared, restore verified by sha256 against the commit blob (new files removed)."""
import ast, hashlib, os, pathlib, re, shutil, subprocess, sys

COMMIT = os.environ["COMMIT"]; LOGS = pathlib.Path(os.environ["MUTANT_LOGS"])
VW, EN, AP = "users/views.py", "classrooms/services/enrollment.py", "users/admin_power.py"
P = "users.tests_vf2_h203_probe."
MINE = [P + "VF2Google", P + "VF2Invitation", P + "VF2AddStudentRoutes", P + "VF2LicenceRoadFindings"]
LIC = "billing.tests.test_licence_invite_admin_power"; LS = "billing/license_service.py"
l1 = "test_l1_the_licence_teacher_road_does_not_replace_the_password_of_an_unverified_admin_power_row"
D5 = "users.tests_admin_power_principle"; PIN = "users.tests_roads_that_sign_in_or_activate"
FINDINGS = P + "VF2LicenceRoadFindings"
g1 = "test_g1_a_never_verified_inactive_admin_power_account_is_refused_and_left_alone"
g2 = "test_g2_the_refusal_is_the_same_bytes_as_an_ordinary_failed_google_sign_in"
g3 = "test_g3_the_refusal_changes_no_column_and_issues_no_token"
i1 = "test_i1_a_pending_row_carrying_is_superuser_gets_the_wrong_token_answer_and_is_left_alone"
a1, a2 = "test_a1_add_by_email_refuses_a_student_typed_row_carrying_is_staff", "test_a2_add_by_email_refuses_a_student_typed_row_carrying_is_superuser"
a3, a5 = "test_a3_direct_add_refuses_the_same_rows", "test_a5_a_verified_switched_off_row_with_admin_power_gets_the_not_a_student_answer"
GS, GF, GT, GC = ("test_google_refuses_a_never_verified_staff_account", "test_google_refuses_a_never_verified_superuser_flag",
                  "test_google_refuses_a_never_verified_super_admin_type", "test_google_refuses_a_command_line_superuser")
P1A = "users.tests_vf1a_h203"
V1T = "test_v1_a_never_verified_account_with_admin_power_is_refused_and_nothing_leaves"
GA = "users.tests_google_auth.GoogleAuthViewTests"
ORD_G = "test_the_refusal_is_raised_before_any_write_to_the_account"; ORD_L = ORD_G
SA_T = "test_a_dormant_never_verified_super_admin_is_not_activated_by_google"
# written reasons (rule 22): mutant -> {test: regex that must stand inside that test's own FAIL block}
FRAG = {"R4_add_student_check_removed": {"test_a3_direct_add_refuses_the_same_rows": r"\d+ not greater than or equal to 400"}, "S9_google_queues_a_sync_then_refuses": {V1T: "safe_delay was called before the refusal"}, "S10_google_stamps_the_sign_in_then_refuses": {V1T: "the sign-in was stamped"},
        "R1b_google_arm_off_judged_by_1a": {V1T: r"200 != 400"}, "A2_helper_forgets_the_super_admin_type_judged_by_the_old_google_module": {SA_T: r"200 != 400"},"S8_google_stamps_the_email_then_refuses": {ORD_G: r"\d+ != 0"}, "S20_licence_guard_attaches_the_school_then_refuses": {ORD_L: r"\d+ != 0"},
        "A1_google_arm_off_judged_by_the_old_google_module": {SA_T: r"200 != 400"}}
PIN_T = "test_every_site_is_on_the_named_list_with_its_count"


def swap(key, new_line_fn):
    def f(src):
        lines = src.split("\n"); hits = [i for i, l in enumerate(lines) if key in l]
        if len(hits) != 1: return None
        i = hits[0]; lines[i] = new_line_fn(lines[i]); return "\n".join(lines)
    return f
def after(key, text):
    def f(src):
        lines = src.split("\n"); hits = [i for i, l in enumerate(lines) if key in l]
        if len(hits) != 1: return None
        lines.insert(hits[0] + 1, text); return "\n".join(lines)
    return f
def second_hit(key, text):
    def f(src):
        lines = src.split("\n"); hits = [i for i, l in enumerate(lines) if key in l]
        if len(hits) != 2: return None
        i = hits[1]; ind = lines[i][:len(lines[i]) - len(lines[i].lstrip())]; lines.insert(i, ind + text); return "\n".join(lines)
    return f
def create(text): return lambda src: text

# name -> (path, transform, labels, must-fail tests)
M = {
 "R1_google_check_removed": (VW, swap("if user.email_verified_at is None and _holds_admin_power(user):", lambda l: l.replace("user.email_verified_at is None and _holds_admin_power(user)", "False")), MINE + [D5], [GS, GF, GT, GC, g1, g3]),
 "R2_google_check_only_for_active_rows": (VW, swap("if user.email_verified_at is None and _holds_admin_power(user):", lambda l: l.replace("if user.email_verified_at", "if user.is_active and user.email_verified_at")), MINE + [D5], [g1]),
 "R3_invitation_check_removed": (VW, swap("if not user or _holds_admin_power(user):", lambda l: l.replace(" or _holds_admin_power(user)", "")), MINE + [D5], ["test_the_invitation_road_refuses_a_pending_row_carrying_is_staff", "test_the_invitation_road_refuses_a_pending_row_carrying_is_superuser", i1]),
 "R4_add_student_check_removed": (EN, swap("if student.user_type != UserTypes.STUDENT or holds_admin_power(student):", lambda l: l.replace(" or holds_admin_power(student)", "")), MINE + [D5, "classrooms.tests_h203_admin_power_routes"], ["test_single_add_refuses_a_student_typed_row_carrying_is_staff", "test_single_add_refuses_a_student_typed_row_carrying_is_superuser", "test_bulk_import_refuses_a_student_typed_row_carrying_is_staff", "test_bulk_import_refuses_a_student_typed_row_carrying_is_superuser", "test_direct_add_refuses_a_student_typed_row_carrying_is_staff", "test_direct_add_refuses_a_student_typed_row_carrying_is_superuser", "test_a_student_typed_row_carrying_is_staff_is_refused", "test_a_student_typed_row_carrying_is_superuser_is_refused", a1, a2, a3, a5]),
 "R6_helper_ignores_is_superuser": (AP, swap("user.is_staff or user.is_superuser or user.user_type", lambda l: l.replace("user.is_superuser or ", "")), MINE + [D5], [GF, "test_the_invitation_road_refuses_a_pending_row_carrying_is_superuser", "test_a_student_typed_row_carrying_is_superuser_is_refused", a2, i1, g2]),
 "R7_helper_ignores_the_super_admin_type": (AP, swap("user.is_staff or user.is_superuser or user.user_type", lambda l: l.replace(" or user.user_type == UserTypes.SUPER_ADMIN", "")), MINE + [D5], [GT, g3]),
 "R8_google_refusal_has_its_own_text": (VW, swap("raise ParseError(GOOGLE_SIGN_IN_FAILED)", lambda l: l.replace("GOOGLE_SIGN_IN_FAILED", '"This account cannot use Google sign-in."')), MINE + [D5], ["test_that_refusal_is_the_failed_google_sign_in_answer", g2]),
 "L1_licence_admin_power_clause_removed": (LS, swap("if (holds_admin_power(user) and user.email_verified_at is None) or (", lambda l: l.replace("holds_admin_power(user) and user.email_verified_at is None", "False")), MINE + [LIC], [l1, "test_a_never_verified_staff_teacher_is_refused_and_untouched"]),
 "L2_licence_switched_off_clause_removed": (LS, swap("user.email_verified_at is not None and not user.is_active", lambda l: l.replace("user.email_verified_at is not None and not user.is_active", "False")), MINE + [LIC], ["test_a_switched_off_verified_teacher_is_refused_and_untouched"]),
 "S8_google_stamps_the_email_then_refuses": (VW, swap("raise ParseError(GOOGLE_SIGN_IN_FAILED)", lambda l: l[:len(l)-len(l.lstrip())] + "user.email_verified_at = __import__('django.utils.timezone', fromlist=['now']).now(); user.save(update_fields=['email_verified_at'])\n" + l), MINE + [D5], [ORD_G]),
 "S20_licence_guard_attaches_the_school_then_refuses": (LS, second_hit("error_msg = \"This email can't be added as a teacher.\"", "user.school = school; user.save(update_fields=['school'])"), MINE + [LIC], [ORD_L]),
 "A1_google_arm_off_judged_by_the_old_google_module": (VW, swap("if user.email_verified_at is None and _holds_admin_power(user):", lambda l: l.replace("user.email_verified_at is None and _holds_admin_power(user)", "False")), [GA + ".test_a_dormant_never_verified_super_admin_is_not_activated_by_google", GA + ".test_every_role_loses_a_pre_set_password_when_google_activates_the_row"], [SA_T]),
 "S9_google_queues_a_sync_then_refuses": (VW, swap("raise ParseError(GOOGLE_SIGN_IN_FAILED)", lambda l: l[:len(l)-len(l.lstrip())] + "safe_delay(sync_user_to_mailerlite, str(user.id))\n" + l), [P1A], [V1T]),
 "S10_google_stamps_the_sign_in_then_refuses": (VW, swap("raise ParseError(GOOGLE_SIGN_IN_FAILED)", lambda l: l[:len(l)-len(l.lstrip())] + "stamp_last_login(user)\n" + l), [P1A], [V1T]),
 "R1b_google_arm_off_judged_by_1a": (VW, swap("if user.email_verified_at is None and _holds_admin_power(user):", lambda l: l.replace("user.email_verified_at is None and _holds_admin_power(user)", "False")), [P1A], [V1T]),
 "A2_helper_forgets_the_super_admin_type_judged_by_the_old_google_module": (AP, swap("user.is_staff or user.is_superuser or user.user_type", lambda l: l.replace(" or user.user_type == UserTypes.SUPER_ADMIN", "")), [GA + ".test_a_dormant_never_verified_super_admin_is_not_activated_by_google"], [SA_T]),
 "P1_a_new_token_site_in_a_pinned_file": (VW, after("from users.tokens import EpochRefreshToken", "_VF2_NEW_ROAD = lambda user: EpochRefreshToken.for_user(user)"), [PIN], [PIN_T]),
 "P2_a_new_file_with_a_token_site": ("users/vf2_new_road.py", create("def new_road(user):\n    return EpochRefreshToken.for_user(user)\n"), [PIN], [PIN_T]),
 "P3_a_password_by_mail_road_the_pin_must_see": ("users/vf2_blind_road.py", create("def blind_road(user, password):\n    user.set_password(password)\n    user.save()\n"), [PIN], [PIN_T]),
}
ENV = {**os.environ, "EXEMPT_EMAIL_DOMAINS": "", "PYTHONDONTWRITEBYTECODE": "1"}
def sha(b): return hashlib.sha256(b).hexdigest()
def clear(): 
    for d in ("users", "classrooms"): shutil.rmtree(pathlib.Path(d) / "__pycache__", ignore_errors=True)
def run(labels, name):
    LOGS.mkdir(parents=True, exist_ok=True); log = LOGS / name
    with open(log, "wb") as fh:
        p = subprocess.run([sys.executable, "-B", "manage.py", "test", *labels, "--settings=settings_worktree", "--noinput", "--keepdb", "-v1"],
                           stdout=fh, stderr=subprocess.STDOUT, env=ENV, stdin=subprocess.DEVNULL)
    o = log.read_text(errors="replace")
    failing = sorted(set(re.findall(r"^(?:FAIL|ERROR): (\w+)", o, re.M)))
    ran = next((l for l in o.splitlines() if l.startswith("Ran ")), "Ran ?")
    summ = next((l for l in o.splitlines() if l.startswith(("OK", "FAILED"))), f"? rc={p.returncode}")
    return p.returncode, ran, summ, failing, o
if sys.argv[1:] == ["check"]:
    for n, (path, fn, *_r) in M.items():
        new = fn(open(path).read() if os.path.exists(path) else ""); print(n, path, "APPLIES" if new is not None else "APPLY_FAILED")
        if new is not None and path.endswith(".py"): ast.parse(new)
    sys.exit()
if sys.argv[1:] == ["baseline"]:
    clear(); rc, ran, summ, failing, o = run(MINE + [D5, PIN, P1A], "baseline.txt"); print("baseline |", ran, "|", summ, "|", failing, flush=True)
    if rc: print(o[-8000:])
    sys.exit(rc)
if sys.argv[1:] == ["findings"]:
    rc, ran, summ, failing, o = run([FINDINGS], "findings.txt"); print("findings (l1 PREDICTED RED) |", ran, "|", summ, "|", failing, flush=True); sys.exit(0)
for name, (path, fn, labels, must) in M.items():
    existed = os.path.exists(path)
    src = open(path).read() if existed else ""
    new = fn(src)
    if new is None: print(name, "APPLY_FAILED", path, flush=True); continue
    ast.parse(new)
    try:
        clear(); open(path, "w").write(new)
        rc, ran, summ, failing, _ = run(labels, f"{name}.txt")
        if rc == 0: st = "SURVIVED"
        elif ran == "Ran ?" or not failing: st = "BROKEN"
        elif all(t in failing for t in must): st = "KILLED"
        else: st = "KILLED_OTHER"
        frag = {}
        for t, rx in FRAG.get(name, {}).items():
            m = re.search(r"^(?:FAIL|ERROR): " + t + r" \(.*?\n-+\n(.*?)(?=^={70}|\Z)", _, re.M | re.S)
            frag[t] = bool(m and re.search(rx, m.group(1)))
        print(name, "|", st, "|", ran, "|", summ, "| must", must, "| failing", failing, "| written reasons seen", frag or "-", flush=True)
    finally:
        if existed: subprocess.run(["git", "checkout", "--", path], check=True)
        else: os.remove(path)
        clear()
        if existed: ok = sha(open(path, "rb").read()) == sha(subprocess.run(["git", "show", f"{COMMIT}:{path}"], capture_output=True).stdout)
        else: ok = not os.path.exists(path)
        print("  restore", path, "ok" if ok else "MISMATCH", flush=True)
