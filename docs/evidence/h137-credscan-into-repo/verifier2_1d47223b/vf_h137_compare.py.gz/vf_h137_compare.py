#!/usr/bin/env python3
"""v2, H-137: compare two masked reports of credscan (`--all`) on one revision.

The reports hold no value: kind, line count, value length, shape, file.
Usage: vf_h137_compare.py identical|superset <old report> <new report>

identical  the two reports must be the same text (the claim "moved, not
           changed" for the tool as it came into the repository).
superset   every row of the old report must be in the new one with a count
           at least as high. Rows that are new or have a higher count are
           counted by kind; those of kind url or assign are LISTED (they
           are hits on lines the old tool passed over), for judgement.
Exit 0 when the claim holds, 1 when it does not.
"""

import collections
import re
import sys

ROW = re.compile(r"^(\w+)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(.+?)\s*\|\s*(.*)$")


def read(path):
    rows, notes = collections.Counter(), []
    for line in open(path, encoding="utf-8", errors="replace").read().splitlines():
        m = ROW.match(line)
        if m and m.group(1) != "kind":
            kind, count, length, shape, name = m.groups()
            rows[(kind, int(length), shape, name)] += int(count)
        else:
            notes.append(line)
    return rows, notes


mode, old_path, new_path = sys.argv[1:4]
old, old_notes = read(old_path)
new, new_notes = read(new_path)
print(f"old: {sum(old.values())} lines in {len(old)} rows | new: {sum(new.values())} lines in {len(new)} rows")

if mode == "identical":
    same = open(old_path, "rb").read() == open(new_path, "rb").read()
    print("the two reports are the same text:", same)
    if not same:
        print("rows only in old:", len(set(old) - set(new)), "| only in new:", len(set(new) - set(old)),
              "| counts differ:", sum(1 for k in set(old) & set(new) if old[k] != new[k]),
              "| note lines differ:", old_notes != new_notes)
    sys.exit(0 if same else 1)

lost = sorted(k for k in old if k not in new)
lower = sorted(k for k in old if k in new and new[k] < old[k])
more = sorted(k for k in new if new[k] > old.get(k, 0))
print("rows of the old report missing from the new one:", len(lost))
for k in lost:
    print("  LOST", k)
print("rows with a lower count in the new one:", len(lower))
for k in lower:
    print("  LOWER", k, old[k], "->", new[k])
by_kind = collections.Counter((k[0], k[2]) for k in more)
print("rows new or with a higher count, by kind and shape:")
for (kind, shape), n in sorted(by_kind.items()):
    print(f"  {kind} | {shape} | {n} row(s)")
listed = [k for k in more if k[0] in ("url", "assign", "cut")]
print("of these, url, assign and cut rows (hits on lines the old tool passed over):", len(listed))
for kind, length, shape, name in listed:
    print(f"  {kind} | length {length} | {shape} | {name} | lines {old.get((kind, length, shape, name), 0)} -> {new[(kind, length, shape, name)]}")
for a, b in zip(old_notes, new_notes):
    if a != b:
        print("note line, old:", a)
        print("note line, new:", b)
if len(old_notes) != len(new_notes):
    print("note lines: old", len(old_notes), "new", len(new_notes))
    for line in new_notes[len(old_notes):]:
        print("note line only in new:", line)
sys.exit(0 if not lost and not lower else 1)
