#!/usr/bin/env python3
"""v2's probe for H-137 (0b): scripts/credscan.py in the repository.

SECOND FORM (r2), 2026-10-07, for the one short repeat the Senior Manager
allowed. The first form (f7b0db9ac7433066) wrote 12 for the length of the
planted value; it is 13 (one letter, eight hex digits, four more). So two
of its three runs read "not as written" although the tool was right, and
its sweep showed nothing. Changed here, and nothing else: the whole
length is taken from the value itself (FULL = len(WORD)); the sweep's
expectation is computed from it (the distances at which the earlier
word's stretch ends inside the value); and the sweep prints what every
distance gave. Where the text below says 12, read "the whole length".

First written 2026-10-07 before anything was run, after reading the tool
and its tests at 46ef23ee; reshaped the same day, still before any run,
after reading the two cures (8d78a179, 71b9807e) at the tip 233e97d1.
It calls the tool's own scan function on bytes made here. The planted value
is made at run time from parts plus random hex; it is never written to disk
and never printed: the output is counts, lengths and shape names only.

It is run on THREE versions of the tool, and every case has an expectation
for each, all written first:
  RECORD  the tool of record outside the repository (as before H-137): a
          line over 4000 characters is passed over in silence, a fourth
          archive too. By v2's reading every long-line case gives nothing.
  FIRST   the first fix, 46ef23ee: v2's reading of the fault found there.
  CURED   the tip: what a checker should give.
An answer is (address rows, lengths of LITERAL assignment rows, lengths of
VALUE-CUT-AT-WINDOW rows) unless the label says otherwise.

  C0  control: a long line, a bare NAME=value, no earlier word near it.
  C1  the word "key" ends 417 characters before the value starts. FIRST:
      the earlier word's stretch is cut 3 characters into the value; the
      cut match is taken for a code expression and the whole one skipped.
  C2  the same with the cut 8 characters in: FIRST gives a LITERAL of 8.
  C3  as C1 with the value in quotes: FIRST is right (a cut quoted value
      cannot match).
  SWEEP  every distance 380 to 440 between the end of the earlier word and
      the start of the value. FIRST: wrong for 409 to 419.
  L1  (H-136's note) a hit far along a long line.
  L3  (H-136's note) a fourth archive inside three: (address rows,
      NOT-OPENED rows).
  K1  a stated limit, as a fact: a password part of 708 characters on a
      long line is not seen; (address rows, longline rows).
  K2  410 blanks between the name and the sign: the value ends past what is
      read. FIRST: a LITERAL of 9 (a quiet untruth). CURED: one cut row of 9.
  K3  416 blanks: FIRST: 3 characters taken for a code expression, nothing
      listed. CURED: one cut row of 3.
  I1  information only, not judged: a name with KEY alone (a cache key) and
      410 blanks. On a short line such a name is only counted. By v2's
      reading the cured tool lists it as a cut row all the same.

Rule 19: every case's expectation differs between at least two of the
three versions, so each case is seen able to fail: C0, C3, L1, L3 and K1
differ between RECORD and the other two; C1, C2, SWEEP, K2 and K3 differ
between FIRST and CURED.

Exit 0: every judged case equals the column named in EXPECT. Exit 1: not.

Usage: TOOL=<path to credscan.py> EXPECT=RECORD|FIRST|CURED \\
       python3 -B vf_h137_credscan_probe.py     (in a slot from 0b)
"""

import collections
import importlib.machinery
import importlib.util
import io
import os
import secrets
import sys
import tarfile

TOOL = os.environ["TOOL"]
EXPECT = os.environ["EXPECT"]
COLUMN = {"RECORD": 0, "FIRST": 1, "CURED": 2}[EXPECT]
WORD = "w" + secrets.token_hex(4) + "Qz" + "7p"  # new each run
FULL = len(WORD)  # never a number written by hand
STRETCH = 420  # the first fix read this far past an earlier word's end
NAME = "DEPLOY_" + "TOKEN"
PAD = b"lorem ipsum " * 400  # 4800 characters, none of the five words


def fresh():
    loader = importlib.machinery.SourceFileLoader("credscan_vf2", TOOL)
    spec = importlib.util.spec_from_loader("credscan_vf2", loader)
    module = importlib.util.module_from_spec(spec)
    loader.exec_module(module)
    return module


def rows_of(data, name="run.log"):
    tool = fresh()
    rows, values = collections.Counter(), collections.defaultdict(set)
    tool.scan("docs/evidence/x/" + name, data, rows, values)
    return rows


def lengths(rows, kind, shape):
    return sorted(
        ln
        for (k, _n, sh, ln), c in rows.items()
        if k == kind and sh == shape
        for _ in range(c)
    )


def count(rows, kind, shape_starts=""):
    return sum(
        c for (k, _n, sh, _l), c in rows.items() if k == kind and sh.startswith(shape_starts)
    )


def answer(data):
    rows = rows_of(data)
    return (
        count(rows, "url"),
        lengths(rows, "assign", "LITERAL"),
        lengths(rows, "cut", "VALUE-CUT-AT-WINDOW"),
    )


def line_with(distance, quoted=False):
    """A long line: the word "key", filler, then NAME=value placed so that
    the value begins `distance` characters after the end of "key"."""
    value = ('"' + WORD + '"') if quoted else WORD
    head = (NAME + "=").encode()
    lead = len(head) + (1 if quoted else 0)  # characters before the value itself
    filler = (b"lorem ipsum " * 60)[: distance - lead - 1] + b" "
    assert len(filler) == distance - lead
    return PAD + b" key" + filler + head + value.encode() + b" " + PAD + b"\n"


def nested_tar(levels, body):
    data, name = body, "run.log"
    for level in range(levels, 0, -1):
        buf = io.BytesIO()
        with tarfile.open(fileobj=buf, mode="w") as t:
            info = tarfile.TarInfo(name)
            info.size = len(data)
            t.addfile(info, io.BytesIO(data))
        data, name = buf.getvalue(), f"level{level}.tar"
    return data


NOTHING = (0, [], [])
WHOLE = (0, [FULL], [])
cases = []  # (label, got, (RECORD, FIRST, CURED))

cases.append(
    (
        "C0 control, no earlier word",
        answer(PAD + (NAME + "=" + WORD).encode() + b" " + PAD + b"\n"),
        (NOTHING, WHOLE, WHOLE),
    )
)
cases.append(("C1 cut 3 into the value", answer(line_with(417)), (NOTHING, NOTHING, WHOLE)))
cases.append(("C2 cut 8 into the value", answer(line_with(412)), (NOTHING, (0, [8], []), WHOLE)))
cases.append(
    ("C3 as C1, value quoted", answer(line_with(417, quoted=True)), (NOTHING, WHOLE, WHOLE))
)

sweep = {d: answer(line_with(d)) for d in range(380, 441)}
wrong_at = [d for d, got in sweep.items() if got != WHOLE]
cases.append(
    (
        "SWEEP the distances 380..440 that do not give the whole value",
        wrong_at,
        # FIRST: the stretch ends inside the value when d < 420 < d + FULL
        (list(range(380, 441)), list(range(STRETCH - FULL + 1, STRETCH)), []),
    )
)

url_line = ("scheme" + ":" + "//" + "someone" + ":" + WORD + "@" + "host.invalid/db").encode()
cases.append(
    (
        "L1 a hit far along a long line",
        answer(PAD + url_line + b" and " + (NAME + ' = "' + WORD + '"').encode() + b"\n"),
        (NOTHING, (1, [FULL], []), (1, [FULL], [])),
    )
)

rows = rows_of(nested_tar(4, url_line + b"\n"), name="logs.tar")
cases.append(
    (
        "L3 a fourth archive: (address rows, NOT-OPENED rows)",
        (count(rows, "url"), count(rows, "archive", "NOT-OPENED")),
        ((0, 0), (0, 1), (0, 1)),
    )
)

long_password = WORD * 59  # far over the 590 that are read
rows = rows_of(
    PAD
    + ("scheme" + ":" + "//" + "someone" + ":" + long_password + "@" + "host.invalid/db").encode()
    + b"\n"
)
cases.append(
    (
        "K1 stated limit: (address rows, longline rows)",
        (count(rows, "url"), count(rows, "longline")),
        ((0, 0), (0, 1), (0, 1)),
    )
)


def blanks_line(name, blanks):
    return PAD + name.encode() + b" " * blanks + b"=" + WORD.encode() + b" " + PAD + b"\n"


cases.append(
    (
        "K2 410 blanks before the sign",
        answer(blanks_line(NAME, 410)),
        (NOTHING, (0, [9], []), (0, [], [9])),
    )
)
cases.append(
    (
        "K3 416 blanks before the sign",
        answer(blanks_line(NAME, 416)),
        (NOTHING, NOTHING, (0, [], [3])),
    )
)

ok = True
for label, got, expected in cases:
    same = got == expected[COLUMN]
    ok &= same
    print(
        f"{label} | got {got} | RECORD {expected[0]} | FIRST {expected[1]} | CURED {expected[2]}"
        f" | equals {EXPECT}: {same}"
    )

print(f"the planted value's length: {FULL}")
print("SWEEP, what each distance gave (address rows, LITERAL lengths, cut lengths):")
for d, got in sweep.items():
    print(f"  {d}: {got}")
info = answer(blanks_line("CACHE_" + "KEY", 410))
print(f"I1 (not judged) a KEY-only name, 410 blanks | got {info} | v2's reading of CURED: (0, [], [9])")

assert WORD not in repr(cases) and WORD not in repr(info)
print(f"every judged case equals {EXPECT}:", ok)
sys.exit(0 if ok else 1)
