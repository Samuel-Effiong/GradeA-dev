"""Value-free context for LITERAL hits: every value the tool's pattern finds
on the line is replaced by <N chars> BEFORE anything is printed; long
unbroken runs are masked too. Usage: context_masked.py <repo> <rev> <file> <line>..."""
import re, subprocess, sys
sys.path.insert(0, "/home/bond-servant-in-training/Documents/Projects/Grade-Automator-Plus-h137-credscan-into-repo/scripts")
import credscan as c
repo, rev, path = sys.argv[1:4]
data = subprocess.run(["git", "-C", repo, "show", f"{rev}:{path}"], capture_output=True, check=True).stdout
lines = data.split(b"\n")
for n in map(int, sys.argv[4:]):
    line = lines[n - 1]
    spans = []
    for m in c.ASSIGN.finditer(line):
        g = 3 if m.group(3) is not None else 4
        spans.append((m.start(1), m.end(1), m.start(g), m.end(g), c.shape(m.group(g), g == 3, path)))
    print(f"== {path} line {n}: {len(line)} bytes, {len(spans)} pattern matches")
    for ns, ne, vs, ve, sh in spans:
        nm = line[ns:ne].upper()
        if sh != "LITERAL" or not any(w in nm for w in (b"PASS", b"PWD", b"SECRET", b"TOKEN")) and not c.STRONG_KEY.search(nm):
            continue
        buf = bytearray(line)
        for _, _, a, b, _ in sorted(spans, key=lambda s: -s[2]):
            lo, hi = max(ns - 110, 0), min(ve + 90, len(line))
            if a >= lo and b <= hi + 200:
                buf[a:b] = b"<%d chars>" % (b - a)
        # recompute the window on the masked buffer around the name
        text = bytes(buf)[max(ns - 110, 0): ns + 260]
        text = re.sub(rb"[A-Za-z0-9+/_\-=]{20,}", lambda m: b"<run %d>" % len(m.group()), text)
        print("  name=%s len=%d | ...%s..." % (line[ns:ne].decode(), ve - vs, text.decode("utf-8", "replace")))
