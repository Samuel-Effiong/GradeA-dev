# H-223 chain config for ../row_chain.py. Written 2026-10-14 by Builder 58
# BEFORE any run, by reading the code at f26e9022 (tip), 3cb3846c (first
# fix), 9dc121e7 and b993c13a (tests only) and the base 913f248f. Revised
# after the Verifier's F1 (a park recorded after an earlier item STARTED
# became a mid-batch stop): the test dispatch now marks items STARTED, the
# routes record every park before any launch, and U8a/U8b put one route
# back to 3cb3846c's order. Nothing here was seen by a run.

ROW = "h223"
WT = "/home/bond-servant-in-training/Documents/Projects/Grade-Automator-Plus-h223"
BASE = "913f248f"  # H-180's door refuses a teacher's whole batch
OUT = "/home/bond-servant-in-training/Documents/Projects/GAP-58-runs/h223"
DB_PREFIX = "test_h223"

ANS = "TheAnswerBatchRunsWhatFits"
ASG = "TheAssignmentUploadRunsWhatFits"


def both(name):
    return (ANS, name), (ASG, name)


T1 = "test_t1_a_dear_file_in_the_middle_is_parked_and_the_others_run"
T2 = "test_t2_the_balance_runs_down_as_files_are_queued"
T3 = "test_t3_a_cheap_file_after_a_dear_one_still_runs"
T4 = "test_t4_when_no_file_fits_the_batch_is_refused_whole"
T5 = "test_t5_the_door_does_not_stamp_the_session"
T6 = "test_t6_one_dear_file_alone_is_refused_as_before"
DOOR_BATCH_POOR = (
    "TeacherBatchDoorTest",
    "test_a_poor_teacher_is_refused_and_nothing_is_queued",
)
DOOR_ASSIGN_POOR = (
    "AssignmentUploadDoorTest",
    "test_a_poor_teacher_is_refused_and_nothing_is_queued",
)
STUDENT_BELOW = (
    "StudentUploadDoorTest",
    "test_a_wallet_below_the_estimate_is_refused_before_anything_is_queued",
)
STUDENT_WORDS = (
    "StudentUploadDoorTest",
    "test_the_sentence_a_student_reads_names_no_money",
)

ROW_MODULE = "students.tests_h223_batch_runs_what_fits"
DOOR_MODULE = "students.tests_upload_credit_door"
MUTANT_LABELS = [ROW_MODULE, DOOR_MODULE]

REFUSED = ("402 != 202",)
BOTH_QUEUED = ("['s0.png', 's1.png'] != ['s0.png']",)

# (r): on the base the door refuses the whole batch at the first file whose
# estimate is above the balance (t1 at s1, t3 at s0, t5 at s1): 402. With
# 30,000 + 30,000 each file fits the balance alone, so the base queues both
# (t2). t4 and t6 (no file fits) are green on the base by design. The two
# restored modules are green on the base (their teacher's wallet now clears
# every file).
R_LABELS = [
    ROW_MODULE,
    "students.tests_batch_item_results",
    "students.tests_credits_mid_batch",
]
R_FROM_TIP = [
    "students/tests_h223_batch_runs_what_fits.py",
    "students/tests_batch_item_results.py",
    "students/tests_credits_mid_batch.py",
]
R_REASON = {}
for _cls in (ANS, ASG):
    R_REASON[(_cls, T1)] = REFUSED
    R_REASON[(_cls, T3)] = REFUSED
    R_REASON[(_cls, T5)] = REFUSED
    R_REASON[(_cls, T2)] = BOTH_QUEUED
REPRO = set(R_REASON)

# (a): every test module that reads the two teacher batch routes or the
# door (the read-only grep over 3cb3846c, a6's slot 12:25, h223-grep.txt),
# and the guard list. No cached payload changes (rule 20 not touched).
A_LABELS = MUTANT_LABELS + [
    "students.tests_batch_item_results",
    "students.tests_credits_mid_batch",
    "assignments.tests_security",
    "assignments.tests_upload_task_retry_policy",
    "audit.tests.test_bench_volume",
    "billing.tests.test_h38_part2_removed_teacher_routes",
    "billing.tests.test_refusal_handling",
    "students.tests_epic_a_submission_upload_audit",
    "students.tests_grading_idempotency",
    "students.tests_h38_n3_refusal_audit",
    "students.tests_h38_tasks_namespace",
    "students.tests_identity_reason_codes",
    "students.tests_item_retry",
    "students.tests_item_retry_h38",
    "students.tests_post_grading_submission_lock",
    "students.tests_s6d_rubric_gate",
    "students.tests_submission_concurrency",
    "students.tests_submission_tenancy",
    "users.tests_auth_endpoints",
    "users.tests_remaining_branches",
    "users.tests_task_viewset",
    "AutoGrader.tests_migration_safety_check",
    "AutoGrader.tests_no_playwright_at_import",
    "AutoGrader.tests_no_wildcard_invalidation",
    "AutoGrader.tests_cache_invalidation_coverage",
    "AutoGrader.tests_migration_rollback_defaults",
    "AutoGrader.tests_redis_test_isolation",
    "AutoGrader.tests_management_commands_are_commands",
    "AutoGrader.tests_no_pii_in_logs",
    "AutoGrader.tests_log_scrubbing",
    "AutoGrader.tests_sentry_scrubbing",
    "billing.tests.test_logs_carry_no_email",
]

STUDENTS_SESSION = """            task_type=BatchUploadType.SUBMISSION,
            total_files=len(files),
        )
"""
ASSIGN_SESSION = """            task_type=BatchUploadType.ASSIGNMENT,
            total_files=len(files),
        )
"""
STAMP = """        if parked:
            BatchUploadSession.objects.filter(pk=session.pk).update(
                credits_exhausted_at=timezone.now()
            )
"""
STUDENTS_GATE = """        parked = parked_files(request.user, assignment, files, prompt)
        if parked and len(parked) == len(files):"""
ASSIGN_GATE = """        parked = parked_files(request.user, None, files, prompt_text)
        if parked and len(parked) == len(files):"""
STUDENT_DOOR = """        refusal = upload_refusal_if_unaffordable(
            request.user, assignment, [uploaded_file], prompt
        )
        if refusal is not None:
            return refusal
"""
STUDENT_DOOR_SWITCHED = """        if parked_files(request.user, assignment, [uploaded_file], prompt):
            return batch_refusal_response()
"""

MUTANTS = {
    # U1 the running subtraction dropped: each 30,000 file fits 50,000 alone.
    "U1": (
        "assignments/upload_door.py",
        "            left -= estimate\n            continue\n",
        "            continue\n",
        MUTANT_LABELS, set(both(T2)), {t: BOTH_QUEUED for t in both(T2)},
    ),
    # U2 everything after the first dear file is parked too.
    "U2": (
        "assignments/upload_door.py",
        '        log_refusal(logger, "Upload door (parked)", parked[index])\n',
        '        log_refusal(logger, "Upload door (parked)", parked[index])\n'
        "        left = -1\n",
        MUTANT_LABELS,
        set(both(T1)) | set(both(T3)),
        {
            **{t: ("['s0.png'] != ['s0.png', 's2.png']",) for t in both(T1)},
            **{t: REFUSED for t in both(T3)},
        },
    ),
    # U3a/U3b the door's session stamped when a file is parked.
    "U3a": (
        "students/views.py", STUDENTS_SESSION, STUDENTS_SESSION + STAMP,
        MUTANT_LABELS, {(ANS, T5)}, {(ANS, T5): ("is not None",)},
    ),
    "U3b": (
        "assignments/views.py", ASSIGN_SESSION, ASSIGN_SESSION + STAMP,
        MUTANT_LABELS, {(ASG, T5)}, {(ASG, T5): ("is not None",)},
    ),
    # U4a/U4b the whole batch refused again when any file is parked.
    "U4a": (
        "students/views.py", STUDENTS_GATE,
        STUDENTS_GATE.replace("parked and len(parked) == len(files)", "parked"),
        MUTANT_LABELS, {(ANS, t) for t in (T1, T2, T3, T5)},
        {(ANS, t): REFUSED for t in (T1, T2, T3, T5)},
    ),
    "U4b": (
        "assignments/views.py", ASSIGN_GATE,
        ASSIGN_GATE.replace("parked and len(parked) == len(files)", "parked"),
        MUTANT_LABELS, {(ASG, t) for t in (T1, T2, T3, T5)},
        {(ASG, t): REFUSED for t in (T1, T2, T3, T5)},
    ),
    # U5 the parked item carries no credit code.
    "U5": (
        "assignments/upload_door.py",
        "        parked[index] = InsufficientCreditsError(",
        "        parked[index] = RuntimeError(",
        MUTANT_LABELS,
        set(both(T1)) | set(both(T2)) | set(both(T3)),
        {t: ("'' != 'INSUFFICIENT_CREDITS'",) for t in both(T1) + both(T2) + both(T3)},
    ),
    # U6a/U6b no-file-fits no longer refused: a session of parked items.
    "U6a": (
        "students/views.py", STUDENTS_GATE,
        STUDENTS_GATE.replace("parked and len(parked) == len(files)", "False"),
        MUTANT_LABELS, {(ANS, T4), (ANS, T6), DOOR_BATCH_POOR},
        {(ANS, T4): ("202 != 402",), (ANS, T6): ("202 != 402",), DOOR_BATCH_POOR: ("202 != 402",)},
    ),
    "U6b": (
        "assignments/views.py", ASSIGN_GATE,
        ASSIGN_GATE.replace("parked and len(parked) == len(files)", "False"),
        MUTANT_LABELS, {(ASG, T4), (ASG, T6), DOOR_ASSIGN_POOR},
        {(ASG, T4): ("202 != 402",), (ASG, T6): ("202 != 402",), DOOR_ASSIGN_POOR: ("202 != 402",)},
    ),
    # U7 (SM's mutant) the student's single upload switched to the per-file
    # function: a student is told the generic wallet sentence.
    "U7": (
        "students/views.py", STUDENT_DOOR, STUDENT_DOOR_SWITCHED,
        MUTANT_LABELS, {STUDENT_BELOW, STUDENT_WORDS},
        {
            STUDENT_BELOW: ("There aren't enough AI credits available for this.",),
            STUDENT_WORDS: ("'credit' unexpectedly found in",),
        },
    ),
}


# U8: each route's parks recorded inside the loop again, after the
# earlier files were launched: the route file becomes byte-identical to
# 3cb3846c's (checked when this was written). With the fast-worker
# dispatch, the park is read as a mid-batch stop: recoded and the session
# stamped. This is the red reason against 3cb3846c the SM asked for.
U8A_NEW = '        tasks_data = []\n        task_ids = []\n\n        # H-223: every parked file is recorded BEFORE any file is launched.\n        # launch_processing_task dispatches at once, so a park recorded after\n        # an earlier file\'s item STARTED would be read as a mid-batch stop\n        # (batch_credit_refusal: the session stamped, the rest stopped).\n        parked_items = {\n            index: record_refused_item(\n                requested_by=request.user,\n                task_type=BackgroundTaskType.BATCH_ANSWER_UPLOAD,\n                error=error,\n                batch_session=session,\n                assignment=assignment,\n                file_name=files[index].name,\n                item_index=index + 1,\n            )\n            for index, error in parked.items()\n        }\n\n        # FR-A-07 (S7a): every file is an item. One too large for the batch\n        # fails as ITS item (413 FILE_TOO_LARGE) and the others still run;\n        # the whole batch is never refused, nor left half-queued.\n        for item_index, uploaded_file in enumerate(files, start=1):\n            try:\n                validate_upload_size(uploaded_file)\n            except PayloadTooLarge as exc:\n                refused = record_refused_item(\n                    requested_by=request.user,\n                    task_type=BackgroundTaskType.BATCH_ANSWER_UPLOAD,\n                    error=exc,\n                    batch_session=session,\n                    assignment=assignment,\n                    file_name=uploaded_file.name,\n                    item_index=item_index,\n                )\n                tasks_data.append(\n                    {\n                        "file_name": uploaded_file.name,\n                        "task_id": None,\n                        "item_id": refused.id,\n                    }\n                )\n                continue\n\n            if item_index - 1 in parked_items:\n                # H-223: parked (recorded above); uploaded again after a top-up.\n                tasks_data.append(\n                    {\n                        "file_name": uploaded_file.name,\n                        "task_id": None,\n                        "item_id": parked_items[item_index - 1].id,\n                    }\n                )\n                continue\n\n'
U8A_OLD = '        tasks_data = []\n        task_ids = []\n\n        # FR-A-07 (S7a): every file is an item. One too large for the batch\n        # fails as ITS item (413 FILE_TOO_LARGE) and the others still run;\n        # the whole batch is never refused, nor left half-queued.\n        for item_index, uploaded_file in enumerate(files, start=1):\n            try:\n                validate_upload_size(uploaded_file)\n            except PayloadTooLarge as exc:\n                refused = record_refused_item(\n                    requested_by=request.user,\n                    task_type=BackgroundTaskType.BATCH_ANSWER_UPLOAD,\n                    error=exc,\n                    batch_session=session,\n                    assignment=assignment,\n                    file_name=uploaded_file.name,\n                    item_index=item_index,\n                )\n                tasks_data.append(\n                    {\n                        "file_name": uploaded_file.name,\n                        "task_id": None,\n                        "item_id": refused.id,\n                    }\n                )\n                continue\n\n            if item_index - 1 in parked:\n                # H-223: parked, its own item; uploaded again after a top-up.\n                refused = record_refused_item(\n                    requested_by=request.user,\n                    task_type=BackgroundTaskType.BATCH_ANSWER_UPLOAD,\n                    error=parked[item_index - 1],\n                    batch_session=session,\n                    assignment=assignment,\n                    file_name=uploaded_file.name,\n                    item_index=item_index,\n                )\n                tasks_data.append(\n                    {\n                        "file_name": uploaded_file.name,\n                        "task_id": None,\n                        "item_id": refused.id,\n                    }\n                )\n                continue\n\n'

U8B_NEW = '        tasks_data = []\n        # H-223: every parked file is recorded BEFORE any file is launched.\n        # launch_processing_task dispatches at once, so a park recorded after\n        # an earlier file\'s item STARTED would be read as a mid-batch stop\n        # (batch_credit_refusal: the session stamped, the rest stopped).\n        parked_items = {\n            index: record_refused_item(\n                requested_by=request.user,\n                task_type=BackgroundTaskType.BATCH_ASSIGNMENT_UPLOAD,\n                error=error,\n                batch_session=session,\n                file_name=files[index].name,\n                item_index=index + 1,\n            )\n            for index, error in parked.items()\n        }\n        # FR-A-07 (S7a): every file is an item. A malformed or too-large file\n        # fails as ITS item, before anything is dispatched for it, and the\n        # rest still run: this used to raise mid-loop, after the earlier\n        # files\' tasks were already queued (a half-queued session).\n        for item_index, uploaded_file in enumerate(files, start=1):\n            file_name = getattr(uploaded_file, "name", None) or f"file {item_index}"\n            refusal = None\n            if not isinstance(uploaded_file, UploadedFile):\n                refusal = FileUnreadableError(params={"file_name": file_name})\n            else:\n                try:\n                    validate_upload_size(uploaded_file)\n                except PayloadTooLarge as exc:\n                    refusal = exc\n            if refusal is None and item_index - 1 in parked_items:\n                # H-223: parked (recorded above); uploaded again after a top-up.\n                tasks_data.append(\n                    {\n                        "file_name": file_name,\n                        "task_id": None,\n                        "item_id": parked_items[item_index - 1].id,\n                    }\n                )\n                continue\n'
U8B_OLD = '        tasks_data = []\n        # FR-A-07 (S7a): every file is an item. A malformed or too-large file\n        # fails as ITS item, before anything is dispatched for it, and the\n        # rest still run: this used to raise mid-loop, after the earlier\n        # files\' tasks were already queued (a half-queued session).\n        for item_index, uploaded_file in enumerate(files, start=1):\n            file_name = getattr(uploaded_file, "name", None) or f"file {item_index}"\n            refusal = None\n            if not isinstance(uploaded_file, UploadedFile):\n                refusal = FileUnreadableError(params={"file_name": file_name})\n            else:\n                try:\n                    validate_upload_size(uploaded_file)\n                except PayloadTooLarge as exc:\n                    refusal = exc\n            if refusal is None and item_index - 1 in parked:\n                # H-223: parked, its own item; uploaded again after a top-up.\n                refusal = parked[item_index - 1]\n'

MID_BATCH = ("'INSUFFICIENT_CREDITS_MID_BATCH' != 'INSUFFICIENT_CREDITS'",)
STAMPED = ("is not None",)
MUTANTS["U8a"] = (
    "students/views.py", U8A_NEW, U8A_OLD, MUTANT_LABELS,
    {(ANS, T1), (ANS, T2), (ANS, T5)},
    {(ANS, T1): MID_BATCH, (ANS, T2): MID_BATCH, (ANS, T5): STAMPED},
)
MUTANTS["U8b"] = (
    "assignments/views.py", U8B_NEW, U8B_OLD, MUTANT_LABELS,
    {(ASG, T1), (ASG, T2), (ASG, T5)},
    {(ASG, T1): MID_BATCH, (ASG, T2): MID_BATCH, (ASG, T5): STAMPED},
)
