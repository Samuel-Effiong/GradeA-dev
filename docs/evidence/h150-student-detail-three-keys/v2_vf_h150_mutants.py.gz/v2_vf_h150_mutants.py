"""v2 mutants for H-150 (d5: a student's submission detail sends its three
details), beside d5's T1-T5.

Run from the vf2-s1 scratch worktree (detached at COMMIT, with v2's probe
copied to AutoGrader/tests_vf2_h150_probe.py), inside the rule 16/13/12
wrappers, output to a file, stdin from /dev/null (rule 18).
Usage: COMMIT=<sha> MUTANT_LOGS=<dir> python vf_h150_mutants.py check |
baseline | (no args: every mutant).

Every inner run writes its OWN file: "baseline.txt", and for a mutant
"<mutant>_<who judged it>.txt".
Rule 17: every test subprocess runs with PYTHONDONTWRITEBYTECODE=1, and the
__pycache__ of the mutated module's directory is deleted before each mutant
and after each restore; `baseline` deletes it first. Database tests on the
real Redis cache (db 4, as d5's module): --keepdb (database test_vf2_s1,
left for 0b to drop).
"""

import ast
import hashlib
import os
import pathlib
import re
import shutil
import subprocess
import sys

COMMIT = os.environ["COMMIT"]
VW = "students/views.py"
D5 = ["AutoGrader.tests_cache_bespoke_1114"]
PROBE = ["AutoGrader.tests_vf2_h150_probe"]
BASELINE = D5 + PROBE
LOGS = pathlib.Path(os.environ["MUTANT_LOGS"])  # one file per inner run

# Written 2026-10-07 before any run of this row by v2 (rules 18 and 19),
# every line of Q1 to Q3 read against each mutant, controls included: for
# each mutant the tests that must ALL be among the failing ones, and (the
# probe has three tests only) no other. KILLED only with the run's own
# "Ran" line and every named test failing.
Q1 = "test_q1_a_released_paper_follows_the_due_date_and_the_course_name"
Q2 = "test_q2_a_write_with_no_signal_is_not_seen_until_the_key_runs_out"
Q3 = "test_q3_an_assignment_moved_to_another_course"
EXPECTED = {
    # Every read is rendered again. Q1 passes (fresh is what it asks). Q2
    # and Q3 state a staleness and fail at their "still the old one" lines.
    "V1_the_students_detail_is_never_served_from_the_cache": {
        "v2's probe": (PROBE, (Q2, Q3)),
    },
    # The key hangs on a counter nothing moves (the submission's id in the
    # user scope). Q1 fails at its first "reaches" line (the generation
    # line before it holds: the student's own counter still moves). Q2 and
    # Q3 pass: stale is what they ask, and the emptied cache is fresh.
    "V2_the_key_hangs_on_a_counter_nothing_moves": {
        "v2's probe": (PROBE, (Q1,)),
    },
}
PREDICTED_TO_SURVIVE = set()
# Which mutant shows which probe red (rule 19): Q1: V2. Q2: V1. Q3: V1.
# d5's own tests are not run under V1 and V2 (rule 15: d5's T4 and T5 are
# d5's gate); V2 would turn d5's freshness tests red as well.

MUTANTS = {
    "V1_the_students_detail_is_never_served_from_the_cache": (VW, [
        ("        data = cache.get(cache_key)\n",
         "        data = None\n"),
    ]),
    "V2_the_key_hangs_on_a_counter_nothing_moves": (VW, [
        ("            [(SCOPE_USER, request.user.id)],\n",
         "            [(SCOPE_USER, submission.id)],\n"),
    ]),
}


def parts(name):
    """A mutant as a list of (path, edits)."""
    m = MUTANTS[name]
    return m if isinstance(m, list) else [m]


ENV = {**os.environ, "EXEMPT_EMAIL_DOMAINS": "", "PYTHONDONTWRITEBYTECODE": "1"}


def sha(b):
    return hashlib.sha256(b).hexdigest()


def clear_pycache(path):
    shutil.rmtree(pathlib.Path(path).parent / "__pycache__", ignore_errors=True)


def run(labels, log_name):
    """One inner run: output straight to its own file, stdin from the null
    device, no pipe (rule 18). The file is read only after the run ends."""
    LOGS.mkdir(parents=True, exist_ok=True)
    log = LOGS / log_name
    with open(log, "wb") as fh:
        out = subprocess.run(
            [sys.executable, "manage.py", "test", *labels,
             "--settings=settings_worktree", "--noinput", "--keepdb", "-v1"],
            stdout=fh, stderr=subprocess.STDOUT, env=ENV, stdin=subprocess.DEVNULL,
        )
    o = log.read_text(errors="replace")
    failing = sorted(set(re.findall(r"^(?:FAIL|ERROR): (\w+)", o, re.M)))
    ran = next((l for l in o.splitlines() if l.startswith("Ran ")), "Ran ?")
    summary = next((l for l in o.splitlines() if l.startswith(("OK", "FAILED"))), f"? rc={out.returncode}")
    return out.returncode, ran, summary, failing, o


if sys.argv[1:] == ["check"]:
    for name in MUTANTS:
        for path, edits in parts(name):
            src = open(path).read()
            counts = [src.count(old) for old, _ in edits]
            for old, new in edits:
                src = src.replace(old, new, 1)
            ast.parse(src)
            print(name, path, counts, "parses")
    sys.exit()

if sys.argv[1:] == ["baseline"]:
    clear_pycache(VW)
    rc, ran, summary, failing, o = run(BASELINE, "baseline.txt")
    print("baseline |", ran, "|", summary, "|", failing, flush=True)
    if rc != 0:
        print(o[-8000:])
    sys.exit(rc)

for name in sys.argv[1:] or MUTANTS:
    mutated = {}
    bad = False
    for path, edits in parts(name):
        src = open(path).read()
        counts = [src.count(old) for old, _ in edits]
        if counts != [1] * len(edits):
            print(name, "APPLY_FAILED", path, counts, flush=True)
            bad = True
            break
        for old, new in edits:
            src = src.replace(old, new, 1)
        ast.parse(src)
        mutated[path] = src
    if bad:
        continue
    for who, (label_set, expected) in EXPECTED[name].items():
        try:
            for path, text in mutated.items():
                clear_pycache(path)
                open(path, "w").write(text)
            # r2: one file per judgement. The first form wrote both judgements
            # of a mutant to the same file, so the second overwrote the first.
            slug = re.sub(r"[^a-z0-9]+", "_", who.lower()).strip("_")
            rc, ran, summary, failing, _ = run(label_set, f"{name}_{slug}.txt")
            predicted = (name, who) in PREDICTED_TO_SURVIVE
            if rc == 0:
                status = "SURVIVED"
            elif ran == "Ran ?" or not failing:
                status = "BROKEN"
            elif predicted:
                status = "KILLED_NOT_AS_PREDICTED"
            elif all(test in failing for test in expected):
                status = "KILLED"
            else:
                status = "KILLED_OTHER"
            note = " (predicted to survive)" if predicted else ""
            print(name, "|", who, "|", status + note, "|", ran, "|", summary,
                  "| expected", expected, "| failing", failing, flush=True)
        finally:
            for path in mutated:
                subprocess.run(["git", "checkout", "--", path], check=True)
                clear_pycache(path)
                ok = sha(open(path, "rb").read()) == sha(
                    subprocess.run(["git", "show", f"{COMMIT}:{path}"], capture_output=True).stdout
                )
                print("  restore", path, "ok" if ok else "MISMATCH", "| __pycache__ cleared", flush=True)
