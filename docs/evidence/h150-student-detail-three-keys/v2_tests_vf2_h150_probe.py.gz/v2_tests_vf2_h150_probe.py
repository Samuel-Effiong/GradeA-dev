"""v2's probe for H-150 (d5): a student's submission detail sends its three
details. Copy to AutoGrader/tests_vf2_h150_probe.py of the scratch
worktree; never committed to the branch. Written 2026-10-07 before any run
of mine, after reading 6f6a56ca (the three sources, d5's eight tests, the
runner T1 to T5) and the save handlers of Assignment and Course.

Same fixture and real Redis cache as d5's class. NOT a subclass of d5's
test class (its tests would run here a second time and enter my failing
sets): the base is d5's BespokeBase, reached through the module so that
the test loader does not collect it here.

  Q1  d5's "reaches the next read" tests for the due date and the course's
      name are on an UNRELEASED paper. Here the paper is RELEASED: a due
      date the teacher saves and a course the teacher renames each move
      the student's counter and reach the next read; the stored document
      beside them and every other key stay as they were.
  Q2  a limit, stated as a fact: the three are fresh because a SAVE moves
      the student's counter. A write that fires no signal (a queryset
      update) moves nothing: the student's next read still has the old due
      date and the old course name; with the cache emptied the new ones
      are there. So it is the cache and nothing else, for at most the
      key's five minutes.
  Q3  a second limit, stated as a fact: an assignment's save bumps the
      students of the course it is in AFTER the save. When a teacher moves
      an assignment to another course of theirs (the PATCH route sets
      `course` and saves), a student who answered it and is not in the new
      course is not bumped: the next read still has the old course's name;
      with the cache emptied the new one.

Rule 19, every line of Q1 to Q3 read against each mutant (controls too):
  V1 (the student's detail is never served from the cache): Q1 passes,
     every read being fresh. Q2 and Q3 fail at their "still the old one"
     lines. Expected failing: Q2, Q3.
  V2 (the key hangs on a counter nothing moves): Q1 fails at its first
     "reaches" line. Q2 and Q3 pass: their stale lines hold, and the
     emptied cache gives the new values. Expected failing: Q1.
"""

import datetime

from django.core.cache import cache

import AutoGrader.tests_cache_bespoke_1114 as d5s
from assignments.models import Assignment, AssignmentStatus
from AutoGrader.cache_generation import SCOPE_USER, get_generation
from classrooms.models import Course
from students.models import StudentSubmission

THREE = ("assignment_title", "assignment_due_date", "course_title")


def due(day):
    return datetime.datetime(2026, 10, day, 9, 0, tzinfo=datetime.timezone.utc)


class VF2H150Probe(d5s.BespokeBase):
    def setUp(self):
        super().setUp()
        self.other_course = Course.objects.create(
            name="Other Course", teacher=self.teacher, session=self.session
        )
        self.assignment = Assignment.objects.create(
            title="Original Title",
            course=self.course,
            teacher=self.teacher,
            status=AssignmentStatus.PUBLISHED,
            due_date=due(14),
        )
        self.submission = StudentSubmission.objects.create(
            student=self.student, assignment=self.assignment, answers={}
        )
        self.url = f"/api/v1/submissions/{self.submission.id}"

    def generation(self):
        return get_generation(SCOPE_USER, self.student.id)

    def read(self):
        data = self.get(self.student_client, self.url)  # asserts 200
        for key in THREE + ("raw_input", "is_published", "score"):
            self.assertIn(key, data)
        return data

    def assert_original(self, data):
        self.assertEqual(data["assignment_title"], "Original Title")
        self.assertEqual(data["assignment_due_date"], "2026-10-14T09:00:00Z")
        self.assertEqual(data["course_title"], "Original Course")

    def test_q1_a_released_paper_follows_the_due_date_and_the_course_name(self):
        self.get(self.teacher_client, self.url)  # materialises the stored document
        self.submission.refresh_from_db()
        self.assertTrue(self.submission.raw_input)
        self.submission.is_published = True
        self.submission.save()
        before = self.read()
        self.assertTrue(before["is_published"])
        self.assert_original(before)

        generation = self.generation()
        self.assignment.due_date = due(21)
        self.assignment.save()
        self.assertNotEqual(self.generation(), generation)
        middle = self.read()
        self.assertEqual(middle["assignment_due_date"], "2026-10-21T09:00:00Z")

        generation = self.generation()
        self.course.name = "Renamed Course"
        self.course.save()
        self.assertNotEqual(self.generation(), generation)
        after = self.read()
        self.assertEqual(after["course_title"], "Renamed Course")
        self.assertEqual(after["assignment_due_date"], "2026-10-21T09:00:00Z")
        self.assertEqual(after["assignment_title"], "Original Title")

        # the stored document and every other key: as before
        for key in THREE:
            before.pop(key)
            after.pop(key)
        self.assertEqual(before, after)

    def test_q2_a_write_with_no_signal_is_not_seen_until_the_key_runs_out(self):
        before = self.read()
        self.assert_original(before)
        generation = self.generation()

        self.assertEqual(
            Assignment.objects.filter(pk=self.assignment.pk).update(due_date=due(21)),
            1,
        )
        self.assertEqual(
            Course.objects.filter(pk=self.course.pk).update(name="Quietly Renamed"), 1
        )

        self.assertEqual(self.generation(), generation)
        stale = self.read()
        self.assertEqual(stale["assignment_due_date"], "2026-10-14T09:00:00Z")
        self.assertEqual(stale["course_title"], "Original Course")
        cache.clear()
        fresh = self.read()
        self.assertEqual(fresh["assignment_due_date"], "2026-10-21T09:00:00Z")
        self.assertEqual(fresh["course_title"], "Quietly Renamed")

    def test_q3_an_assignment_moved_to_another_course(self):
        before = self.read()
        self.assert_original(before)
        generation = self.generation()

        # what the PATCH route does: set the course, save
        self.assignment.course = self.other_course
        self.assignment.save()

        self.assertEqual(self.generation(), generation)
        stale = self.read()
        self.assertEqual(stale["course_title"], "Original Course")
        cache.clear()
        fresh = self.read()
        self.assertEqual(fresh["course_title"], "Other Course")
