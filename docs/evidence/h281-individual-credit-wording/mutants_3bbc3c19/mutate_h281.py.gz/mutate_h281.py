import hashlib, pathlib, re, subprocess, sys
W = pathlib.Path(sys.argv[1]); PY = sys.argv[2]; OUT = pathlib.Path(sys.argv[3]); LABELS = sys.argv[4].split()
ONLY = sys.argv[5:]
OUT.mkdir(exist_ok=True)
C = "3bbc3c199"
ER, MO, PE, AC, AI, UD = "billing/errors.py", "billing/models.py", "users/permissions.py", "billing/access_control.py", "ai_processor/services.py", "assignments/upload_door.py"
EM, RC, TT, IR = "AutoGrader/error_messages.py", "AutoGrader/reason_codes.py", "students/task_tracking.py", "students/item_results.py"
# (path, line or None, old, new); a line pins a duplicate text to one site.
M = {
 "M-h281.1": [(ER, None, "        and not user.is_under_license()\n", "")],
 "M-h281.2": [(ER, None, 'getattr(user, "user_type", None) == UserTypes.TEACHER', "user.user_type == UserTypes.TEACHER")],
 "M-h281.3": [(MO, 933, "individual=is_individual_teacher(self.user),", "individual=False,")],
 "M-h281.4": [(MO, 942, "individual=is_individual_teacher(self.user),", "individual=False,")],
 "M-h281.5": [(MO, 1048, "individual=is_individual_teacher(self.user),", "individual=False,")],
 "M-h281.6": [(PE, 58, "individual=is_individual_teacher(target_user),", "individual=False,")],
 "M-h281.7": [(AC, 600, "individual=is_individual_teacher(request.user)", "individual=False")],
 "M-h281.8": [(AI, 5594, "individual=is_individual_teacher(user),", "individual=False,")],
 "M-h281.9": [(AI, 5650, "individual=is_individual_teacher(target_teacher),", "individual=False,")],
 "M-h281.10": [(AI, 5656, "individual=is_individual_teacher(target_teacher),", "individual=False,")],
 "M-h281.11": [(UD, 100, "individual=is_individual_teacher(billed),", "individual=False,")],
 "M-h281.12": [(UD, 140, "individual=is_individual_teacher(billed),", "individual=False,")],
 "M-h281.13": [(UD, 150, "individual=is_individual_teacher(billed_user)", "individual=False")],
 "M-h281.14": [(EM, 92, "return credit_refusal_message(error)", "return credit_refusal_message(None)")],
 "M-h281.15": [(RC, 848, "remediation = credit_refusal_remediation(credit_refusal_variant(error))", "remediation = None")],
 "M-h281.16": [(TT, 255, "    if variant is not None:", "    if False:")],
 "M-h281.17": [(IR, 38, 'chosen = credit_refusal_remediation(meta.get("message_variant"))', "chosen = None")],
 "M-h281.18": [(RC, 750, "        and not isinstance(error, CodedError)\n", "")],
 "M-h281.19": [(RC, 281, '"individual": INSUFFICIENT_CREDITS_INDIVIDUAL_MESSAGE,', '"individual": INSUFFICIENT_CREDITS_MESSAGE,')],
}
files = sorted({p for e in M.values() for p, _, _, _ in e})
committed = {p: subprocess.run(["git", "-C", str(W), "show", f"{C}:{p}"], capture_output=True, check=True).stdout for p in files}
SHA = {p: hashlib.sha256(b).hexdigest() for p, b in committed.items()}
sha = lambda p: hashlib.sha256((W / p).read_bytes()).hexdigest()
for p in files:
    assert sha(p) == SHA[p], p
print("committed sha256:", {p: SHA[p][:12] for p in files}, flush=True)

def apply(src, line, old, new):
    lines = src.splitlines(keepends=True)
    if line is None:
        assert src.count(old) == 1, (old, src.count(old))
        return src.replace(old, new, 1)
    if old.endswith("\n"):
        assert lines[line - 1] == old, (line, lines[line - 1])
        lines[line - 1] = new
    else:
        assert lines[line - 1].count(old) == 1, (line, lines[line - 1])
        lines[line - 1] = lines[line - 1].replace(old, new, 1)
    return "".join(lines)

for name, edits in M.items():
    if ONLY and name not in ONLY:
        continue
    touched = sorted({p for p, _, _, _ in edits})
    try:
        for p, line, old, new in edits:
            (W / p).write_text(apply((W / p).read_text(), line, old, new))
        r = subprocess.run([PY, "manage.py", "test", "--noinput", "--settings=settings_worktree", "-v", "2", *LABELS],
                           cwd=W, capture_output=True, text=True, timeout=3600)
        log = r.stdout + r.stderr; rc = r.returncode
    finally:
        for p in touched:
            (W / p).write_bytes(committed[p])
    for p in touched:
        assert sha(p) == SHA[p], "restore failed " + p
    head = "".join(f"{name}: {p}:{line}\n- {old!r}\n+ {new!r}\n" for p, line, old, new in edits)
    (OUT / f"{name}.txt").write_text(f"{head}rc={rc}\nrestored sha256 {', '.join(SHA[p] for p in touched)}\n\n" + log)
    hits = sorted({re.sub(r"^(FAIL|ERROR): (\S+) \(([^)]*)\).*", r"\3", l) for l in log.splitlines() if l.startswith(("FAIL:", "ERROR:"))})
    tail = [l for l in log.splitlines() if l.startswith(("Ran ", "OK", "FAILED"))]
    print(name, "rc=%d" % rc, "restored ok", tail, flush=True)
    for h in hits:
        print("   ", h, flush=True)
