"""Builder 58's gate chain for one small row: (r) seen red on the base,
(a) the gate modules on the frozen tip, (b) the mutants. Stdlib only.

Usage (under ONE systemd-inhibit around the whole command, rule 16):
    python3 row_chain.py <config.py> <tip-sha8>

The config file (a plain Python file next to this one) sets:
    ROW, WT, BASE, OUT, DB_PREFIX
    R_LABELS, R_FROM_TIP, REPRO, R_REASON       (REPRO may be empty: (r) skipped
                                                 when R_LABELS is empty)
    A_LABELS
    MUTANTS = {name: (file, old, new, labels, expected_set, reasons)}
expected sets hold (TestClass, test_name); reasons map such a pair to the
fragments that must be inside that test's OWN failure block (rule 22).

Rules kept: every test command writes to a file with stdin from /dev/null
(rule 18), runs in a MemoryMax scope with a timeout (rules 12, 13), with
--settings=settings_worktree on its own test database; mutants run in a
throwaway worktree at the tip with PYTHONDONTWRITEBYTECODE=1 and the
mutated module's __pycache__ cleared (rule 17); the frozen worktree itself
is never mutated. Throwaway worktrees are removed WITHOUT --force: their
own files are put back first; if git still refuses, the chain says so and
leaves the tree for the Release Engineer.
"""

import hashlib
import os
import re
import runpy
import shutil
import subprocess
import sys
import time
from pathlib import Path

P = Path("/home/bond-servant-in-training/Documents/Projects")
ENV_FILE = P / "Grade-Automator-Plus" / ".env"
WRAP = [
    "systemd-run", "--user", "--scope", "-q",
    "-p", "MemoryMax=6G", "-p", "MemorySwapMax=0",
    "nice", "-n", "10", "timeout", "-k", "60", "1800",
]

LINE = re.compile(r"^(?:FAIL|ERROR): (test_\w+) \(([\w.]+)\)", re.M)
# A subTest failure's header carries its label after the id, e.g.
# "FAIL: test_x (app.mod.Class.test_x) [label]" or "(name='value')".
BLOCK = re.compile(
    r"^(?:FAIL|ERROR): (test_\w+) \(([\w.]+)\)[^\n]*\n(.*?)(?=^(?:FAIL|ERROR): |^Ran \d+ tests)",
    re.M | re.S,
)
RAN = re.compile(r"^Ran (\d+) tests? in ", re.M)


class Stop(Exception):
    pass


def load():
    return Path("/proc/loadavg").read_text().strip()


def git(*args, cwd, check=True):
    return subprocess.run(
        ["git", *args], cwd=cwd, check=check, capture_output=True, text=True
    )


def failing(text):
    return {(path.split(".")[-2], name) for name, path in LINE.findall(text)}


def wrong_reasons(text, reasons):
    """Each written fragment must be inside one of the test's OWN failure
    blocks (a test with failing subTests has one block per subTest). A
    failing test with written reasons and no parsed block is reported,
    never skipped."""
    blocks = {}
    for n, p, body in BLOCK.findall(text):
        blocks.setdefault((p.split(".")[-2], n), []).append(body)
    failed = failing(text)
    out = []
    for test, fragments in reasons.items():
        bodies = blocks.get(test)
        if bodies is None:
            if test in failed:
                out.append(f"{test[1]}: failed, but no failure block was parsed")
            continue  # not failing: reported by the set comparison
        missing = [f for f in fragments if not any(f in body for body in bodies)]
        if missing:
            out.append(f"{test[1]}: not in its own failure block: {missing}")
    return out


def compare(label, got, expected):
    extra, missing = got - expected, expected - got
    same = got == expected
    msg = f"{label}: {len(got)} failing, {'as expected' if same else 'DIFFERS'}"
    if extra:
        msg += f"; unexpected: {sorted(extra)}"
    if missing:
        msg += f"; expected but passed: {sorted(missing)}"
    return same, msg


class Chain:
    def __init__(self, cfg, tip):
        self.c = cfg
        self.tip = tip
        self.out = Path(cfg["OUT"])
        self.status = self.out / "chain.status"

    def say(self, text):
        line = f"{time.strftime('%H:%M:%S')} {text}"
        print(line, flush=True)
        with self.status.open("a") as fh:
            fh.write(line + "\n")

    def settings(self, tree, db):
        (tree / "settings_worktree.py").write_text(
            "from AutoGrader.settings import *  # noqa: F401,F403\n"
            "from AutoGrader.settings import DATABASES\n\n"
            'DATABASES["default"].setdefault("TEST", {})\n'
            f'DATABASES["default"]["TEST"]["NAME"] = {db!r}\n'
        )

    def run_tests(self, tree, labels, log, verbosity=1):
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", EXEMPT_EMAIL_DOMAINS="")
        cmd = WRAP + [
            "python", "manage.py", "test", *labels,
            "--settings=settings_worktree", "--noinput", f"--verbosity={verbosity}",
        ]
        self.say(f"start {log.name}: loadavg {load()}")
        t0 = time.time()
        with log.open("w") as fh, open(os.devnull) as devnull:
            rc = subprocess.run(
                cmd, cwd=tree, stdout=fh, stderr=subprocess.STDOUT,
                stdin=devnull, env=env,
            ).returncode
        with log.open("a") as fh:
            fh.write(f"exit={rc} wall_s={int(time.time() - t0)}\n")
        self.say(f"end {log.name}: exit={rc} loadavg {load()}")
        return rc, log.read_text(errors="replace")

    def add_tree(self, path, commit):
        if path.exists():
            raise Stop(f"{path} exists already")
        git("worktree", "add", "--detach", str(path), commit, cwd=self.c["WT"])
        (path / ".env").symlink_to(ENV_FILE)

    def remove_tree(self, path, written=()):
        """No --force: put back what the chain changed, delete its own
        files (and each of `written` the base does not track: a test file
        new at the tip), then ask git to remove a clean tree."""
        if not path.exists():
            return
        for rel in written:
            tracked = git("ls-files", "--error-unmatch", rel, cwd=path, check=False)
            if tracked.returncode != 0 and (path / rel).exists():
                (path / rel).unlink()
        git("checkout", "--", ".", cwd=path, check=False)
        for name in (".env", "settings_worktree.py"):
            f = path / name
            if f.is_symlink() or f.exists():
                f.unlink()
        for cache in path.rglob("__pycache__"):
            shutil.rmtree(cache, ignore_errors=True)
        done = git("worktree", "remove", str(path), cwd=self.c["WT"], check=False)
        if done.returncode != 0:
            self.say(f"WARNING: git would not remove {path} without --force "
                     f"({done.stderr.strip()}); left for the Release Engineer")
        git("worktree", "prune", cwd=self.c["WT"], check=False)

    # -- the stages ------------------------------------------------------------

    def preflight(self):
        wt = Path(self.c["WT"])
        head = git("rev-parse", "--short=8", "HEAD", cwd=wt).stdout.strip()
        dirty = git("status", "--porcelain", cwd=wt).stdout.strip()
        if head != self.tip or dirty:
            raise Stop(f"tree not frozen at {self.tip} (HEAD {head}, dirty={bool(dirty)})")
        for name in (f"r_{self.c['BASE']}.log", f"a_{self.tip}.log", f"b_{self.tip}"):
            if (self.out / name).exists():
                raise Stop(f"{name} exists already: logs of this chain exist")

    def stage_r(self):
        if not self.c["R_LABELS"]:
            self.say("(r) none: no test of this row is red on the base by design")
            return
        rw = P / f"Grade-Automator-Plus-{self.c['ROW']}-repro"
        self.add_tree(rw, self.c["BASE"])
        try:
            for f in self.c["R_FROM_TIP"]:
                blob = git("show", f"{self.tip}:{f}", cwd=self.c["WT"]).stdout
                (rw / f).write_text(blob)
            self.say(f"(r) {' '.join(self.c['R_FROM_TIP'])} taken from {self.tip}; "
                     f"the rest is {self.c['BASE']}")
            self.settings(rw, f"{self.c['DB_PREFIX']}_repro")
            rc, text = self.run_tests(rw, self.c["R_LABELS"], self.out / f"r_{self.c['BASE']}.log")
        finally:
            self.remove_tree(rw, self.c["R_FROM_TIP"])
        if rc != 1 or not RAN.search(text):
            raise Stop(f"(r) did not end red in the ordinary way (exit {rc})")
        same, msg = compare("(r)", failing(text), self.c["REPRO"])
        self.say(msg)
        bad = wrong_reasons(text, self.c["R_REASON"])
        for line in bad:
            self.say(f"(r) WRONG REASON: {line}")
        if not same or bad:
            raise Stop("(r) the red set or a reason differs from the written one")
        self.say("(r) the red set is the expected one, each for its written reason")

    def stage_a(self):
        wt = Path(self.c["WT"])
        self.settings(wt, f"{self.c['DB_PREFIX']}_a")
        try:
            rc, text = self.run_tests(wt, self.c["A_LABELS"], self.out / f"a_{self.tip}.log", 2)
        finally:
            (wt / "settings_worktree.py").unlink()
        ran = RAN.search(text)
        self.say(f"(a) exit={rc} {ran.group(0).strip() if ran else 'NO Ran LINE'}")
        if rc != 0 or not ran:
            raise Stop("(a) red")

    def stage_b(self):
        mw = P / f"Grade-Automator-Plus-{self.c['ROW']}-mut"
        logs = self.out / f"b_{self.tip}"
        logs.mkdir()
        self.add_tree(mw, self.tip)
        bad = 0
        try:
            self.settings(mw, f"{self.c['DB_PREFIX']}_mut")
            labels = sorted({l for m in self.c["MUTANTS"].values() for l in m[3]})
            rc, text = self.run_tests(mw, labels, logs / "baseline.log")
            if rc != 0 or not RAN.search(text):
                raise Stop("(b) baseline is not green")
            for name, (rel, old, new, mlabels, expected, reasons) in self.c["MUTANTS"].items():
                path = mw / rel
                source = path.read_text()
                sha = hashlib.sha256(source.encode()).hexdigest()
                if source.count(old) != 1:
                    raise Stop(f"{name}: anchor found {source.count(old)} times in {rel}")
                path.write_text(source.replace(old, new))
                shutil.rmtree(path.parent / "__pycache__", ignore_errors=True)
                try:
                    rc, text = self.run_tests(mw, mlabels, logs / f"{name}.log")
                finally:
                    path.write_text(source)
                    shutil.rmtree(path.parent / "__pycache__", ignore_errors=True)
                    if hashlib.sha256(path.read_text().encode()).hexdigest() != sha:
                        raise Stop(f"{name}: restore of {rel} failed its sha check")
                if rc in (124, 137):
                    self.say(f"{name}: exit {rc}: a hang or a cap, NOT a kill")
                    bad += 1
                    continue
                if "ImportError" in text and not RAN.search(text):
                    self.say(f"{name}: a load failure, NOT a kill")
                    bad += 1
                    continue
                same, msg = compare(name, failing(text), expected)
                self.say(msg)
                wrong = wrong_reasons(text, reasons)
                for line in wrong:
                    self.say(f"{name} WRONG REASON: {line}")
                if not RAN.search(text) or not same or wrong or rc == 0:
                    bad += 1
        finally:
            self.remove_tree(mw)
        if bad:
            raise Stop(f"(b) {bad} mutant(s) not killed as written")
        self.say("(b) every mutant killed, each failing set and reason as written")


def main():
    cfg = runpy.run_path(sys.argv[1])
    chain = Chain(cfg, sys.argv[2])
    chain.out.mkdir(parents=True, exist_ok=True)
    chain.say(f"{cfg['ROW']} chain on {chain.tip}, base {cfg['BASE']}: loadavg {load()}")
    try:
        chain.preflight()
        chain.stage_r()
        chain.stage_a()
        chain.stage_b()
    except Stop as stop:
        chain.say(f"STOP: {stop}")
        chain.say("CHAIN END (stopped)")
        return 1
    chain.say(f"{cfg['ROW']} CHAIN END: green as written")
    return 0


if __name__ == "__main__":
    sys.exit(main())
